#include "STC15Fxxxx.h"
#include "oneline.h"
uint8 ASC_To_Valu(uint8 asc)
{	
	uint8 valu;
	switch(asc)
	{
		case 0x30:valu=0;break;
		case 0x31:valu=1;break;
		case 0x32:valu=2;break;
		case 0x33:valu=3;break;
		case 0x34:valu=4;break;
		case 0x35:valu=5;break;
		case 0x36:valu=6;break;
		case 0x37:valu=7;break;
		case 0x38:valu=8;break;
		case 0x39:valu=9;break;
	}
	return valu;
}

void u32tostr(unsigned long dat,char *str) 
{
 char  temp[20]={0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};
 unsigned char  i=0,j=0;
 i=0;
 while(dat)
 {
  temp[i]=dat%10+0x30;
  i++;
  dat/=10;
 }
 j=i;
 for(i=0;i<j;i++)
 {
  str[i]=temp[j-i-1];
 } 
 str[i]='\0';
}

//void Valu_to_ASC(uint16 valu,uint8 *asc)		//100��
//{
//	uint16 valu_wei[4];		   
//	uint8 i;
//	while(valu>9999)
//		valu-=10000;
//	valu_wei[0]=valu/1000;
//	valu_wei[1]=(valu/100)%10;  //��λ
//	valu_wei[2]=valu/10-100*valu_wei[0]-10*valu_wei[1];
//	valu_wei[3]=valu%10;
//	for(i=0;i<4;i++)
//	{
//		switch(valu_wei[i])
//		{
//			case 0:asc[i]=0x30;break;
//			case 1:asc[i]=0x31;break;
//			case 2:asc[i]=0x32;break;
//			case 3:asc[i]=0x33;break;
//			case 4:asc[i]=0x34;break;
//			case 5:asc[i]=0x35;break;
//			case 6:asc[i]=0x36;break;
//			case 7:asc[i]=0x37;break;
//			case 8:asc[i]=0x38;break;
//			case 9:asc[i]=0x39;break;
//		}
//	}
//
//
//}
