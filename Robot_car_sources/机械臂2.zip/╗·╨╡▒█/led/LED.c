
#include "LED/led.h"
#include "ps2/ps2.h"


void LED1_ON()
{
	LED1 = 0;
}
void LED1_ON_OR_OFF()
{
	LED1 = ~LED1;
}
void LED1_OFF()
{
	LED1 = 1;
}
void LED2_ON()
{
	LED2 = 0;
}
void LED2_OFF()
{
	LED2 = 0;
}
void LED2_ON_OR_OFF()
{
	LED2 = ~LED2;
}
void LED3_ON()
{
	LED3 = 0;
}
void LED3_OFF()
{
	LED3 = 1;
}
void LED_ALL_ON()
{
	LED1 = 0;
	LED2 = 0;
	LED3 = 0;
}
void LED_ALL_OFF()
{
	LED1 = 1;
	LED2 = 1;
	LED3 = 1;
}
void BEEP_ON()
{
	BEEP = 0;
}
void BEEP_On_Or_OFF()
{

	BEEP_ON();
	delayms(200);
	BEEP_OFF();
	delayms(200);
}
void BEEP_OFF()
{
	BEEP = 1;
}