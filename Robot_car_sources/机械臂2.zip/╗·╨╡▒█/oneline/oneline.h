#ifndef ONELINE
#define ONELINE
extern void OneLine(uint8 *str);
#endif
