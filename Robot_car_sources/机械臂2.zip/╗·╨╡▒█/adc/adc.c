#include "adc.h"
#include "STC15Fxxxx.H"
#include "ps2/delay.h"
#include "uart.h"
#define ADC_POWER 0x80
#define ADC_FLAG 0x10
#define ADC_START 0x08

#define ADC_SPEEDL 0x20
extern unsigned char ad_value ;
extern bit flag_read_adc;
void InitADC(unsigned char ch)
{
	P1ASF |= 1 << ch;
	ADC_RES = 0;
	IE |= 0xa0;
}
void StartADC(unsigned char ch)
{
	ADC_CONTR = ADC_POWER | ADC_SPEEDL | ADC_START  | ch;
	delay(2);
}
void adc_isr() interrupt 5 using 1
{
	ADC_CONTR &= !ADC_FLAG;
	ad_value = ADC_RES;
	ADC_CONTR &= ~ADC_POWER;
	flag_read_adc = 1;
}