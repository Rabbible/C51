#ifndef _ADC_H__
#define _ADC_H__
void InitADC(unsigned char ch);
void StartADC(unsigned char ch);
#endif