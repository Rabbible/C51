
#include "STC15Fxxxx.H"  //STC15ϵ�е�Ƭ��
#include <intrins.h>
#include "UART.H"
#include "timer.h"
#include "util.h"
#include "ps2/ps2.h"
#include "flash/flash.h"//ͷ�ļ�
#include <string.h>
#include <stdio.h>
#include "LED/led.h"
#include <string.h>
#include <stdlib.h>
#include "adc/adc.h"
extern uint8 flag_p;
extern bit flag_RecFul;
//extern uchar KEY[9];
uint16 pos[7][MOTOR_NUM]={ {1000,1500,1500,1500,1500,1500,1500,1500,1500},
                                         {1000,1500,1500,1500,1500,1500,1500,1500,1500},
                                         {1000,1500,1500,1500,1500,1500,1500,1500,1500},
                                         {1000,500,500,500,500,500,500,500,500},
                                         {1000,1500,1500,1500,1500,1500,1500,1500,1500},
                                         {1000,500,500,500,500,500,500,500,500},
                                         {1000,1500,1500,1500,1500,1500,1500,1500,1500}
};         //λ��
uint16 pwm[MOTOR_NUM]=    {1500,1500,1500,1500,1500,1500,1500,1500,1500};
uint16 UartRec[MOTOR_NUM]={1500,1500,1500,1500,1500,1500,1500,1500,1500};
uint8 redata[257] = {0};    // ����������ݱ�������
uint8 line=0;                                        //�������������֮��ľ��룬����ǰ�������ж��ٸ�û��ִ�е�����
uint8 point_now=0;                                //��point_aimһ���ǻ������λ�ã���ȡ��λ��
uint8 point_aim=1;
uint8 point_in=2;                                //��ǻ������λ�ã�����һ�����ݴ��λ��
bit flag_connect = 0;
bit flag_stop=1;                                //��ʾһ��ִ�н���
uint8 flag_vpwm=0;                                //��ʾ�����˸ø���pwm[]��ʱ��
bit flag_in=1;                                         //��ʾ�������п��пռ�
bit flag_out=0;                                        //��ʾ�������п�ִ�����ݵı�־λ
bit flag_run_ready=0;                        //��ʾ��ҪҪ���뻺���EErom����
uint16 n=1000;                                        //����������Ҫ�������ٸ��м�����
uint16 m=1;                                                //�����ۼ��Ѿ�ִ���˶����м�����
double dp;
double dp0[MOTOR_NUM] = {0};                                        //�岹����
bit flag_download = 0;//�ж��Ƿ�����
bit flag_read = 0;// ��ȡflash���ݣ�������λ��
bit flag_connect_run = 0;//������λ����ִ��flash���������
bit flag_stop_download = 0;//ֹͣ����
bit flag_online_run = 0;
bit flag_uart2_rev = 0;
bit flag_uart2_rev_time_out = 0;
bit flag_ps2_rev = 0;
bit flag_read_adc = 0;
unsigned long send_mode = 0;//��ǰ���ڽ��յ�����״̬�洢
MotorData motor_data;//�������Ϣ
MotorOneCmd motor_one_cmd;//��������
CurrentItem cur_item;
uint16 tuoji_count = 0;//�ѻ�ִ�д���
bit flag_scan_ps2 = 0;
uint8 error = 0;
uchar file_list[MAX_SUPPORT_FILE_SAVE] = {0};
int file_list_count = 0;
int file_last_num = 0;
char ps2_buf[120] = {0};
char uart2_buf[50] = {0};
uint cur_count = 0;
uchar ad_value = 0;
uchar beep_mode = 1;
uchar key_bak;
uchar ps2_key;
uchar ps2_mode=0;

void updata_file_list()
{
        uchar i = 0;
        uchar j = 0;
        file_last_num = -1;
        ReadMoterInfor();
        for (i = 0; i < motor_data.filecount; i++)
        {
                if (motor_data.file_flag[i] == 1)
                {
                        file_list[j] = i;
                        j++;
                        file_last_num = i;
                }
        }
        file_list_count = j;
}
void InitMotor()
{
        ReadMoterInfor();//��ȡ���������Ϣ
        updata_file_list();
        memset(&cur_item,0,sizeof(cur_item));
        beep_mode = motor_data.beep_mode;
}

       
void main(void)
{
        uint temp = 0;         
        P0M1=0x00;                                   //����P0��Ϊǿ�������ģʽ
        P0M0=0xFF;
        
        P1M1|=0x80;
        P1M0|=0xc8;
        
        P5M1|=0x00;
  P5M0|=0x2d;
        
        P4M0|=0x20;
        P4M1|=0x00;
        
        Timer_init();          //��ʱ����ʼ��
        Timer0(31);                  //��ʱ����ֵ��������ʱ�������붨ʱ��ѭ��
#if MOTOR_NUM > 9
        Timer1(30);
#endif
        SpiFlashInit();//��ʼ��flash
        while((temp = SpiFlashReadID())!=W25Q64)LED_ALL_ON();//�ж�flash��û�нӴ�
        LED_ALL_OFF();
        InitMotor();
        UART1_Init();          //����1��ʼ��
        UART2_Init();  //����2��ʼ��
#if PS_SUPPORT
        Timer3_init();
#endif        
        InitADC(7);
        BEEP_On_Or_OFF();
        while(1)
        {
                if(flag_vpwm==1)                  
                {        
                        vpwm();                                        //����pwm[]����
                        flag_vpwm=0;                
                }
                if( flag_RecFul==1)                   //���ڽ�����һ��ָ��
                {
                        DealRec();                                 //�������ڻ����е�����
                        flag_RecFul=0;
                }
                GetOneMotorCMD();//��ȡһ������
                SendUartState();//����״̬��Ϣ
#if PS_SUPPORT
                scan_ps2();
#endif
                LED_State();
                Check_Power();
          cur_count++;
        }
}
void Check_Power()
{
        if ((cur_count % 800) == 0)
        {
                StartADC(7);
                //cur_count=0;
        }
        if (flag_read_adc)
        {
                flag_read_adc = 0;
                //UART_Put_Inf("adc:",ad_value);
                if (ad_value > 46)//���ݵ�ѹ���Թ���
                {
                        //UART_Put_Inf("adc:",ad_value);
                  BEEP_OFF();
                //        LED2_OFF();
                }
                else
                {
                                //UART_Put_Inf("adc1111:",ad_value);
                                BEEP=~BEEP;
                                LED1=0;
                                LED2=0;
                                LED3=0;
                }
                
        }
}
void LED_State()
{
        uint error_count =  0;
        if (error != 0)
        {
                if (error & ERROR_FLASH_FULL)
                {
                        error_count = 100;
                }
                if (error & ERROR_FLASH_FILE_FULL)
                {
                        error_count += 100;
                }
                if (error & ERROR_FLASH_WRITE)
                {
                        error_count += 100;
                }
                if (error & ERROR_FLASH_WRITE1)
                {
                        error_count += 100;
                }
                if ((cur_count % error_count) == 0)//�ж�flash�Ƿ���ȷ
                {
                        LED1_ON_OR_OFF();
                }
        }
        
        if (flag_ps2_rev)
        {
                LED1_ON();
                if ((cur_count % 100) == 0)
                {
                        flag_ps2_rev = 0;
                        LED1_OFF();
                }
        }
        if (flag_connect)
        {
                LED3_ON();
        }
        else
        {
                LED3_OFF();
        }
}
void scan_ps2()
{
        int  kind = 0;
        char *p = NULL;
        char buf[15] = {0};
        char i = 0;
        if (flag_scan_ps2)//
        {
                flag_scan_ps2 = 0;
                ps2_key=PS2_DataKey();
                ps2_mode=PS2_RedLight();
        //UART_Put_Inf("mode",ps2_mode);        
                if(ps2_mode==0)
                {
                        if(key_bak == ps2_key)return;
                        key_bak=ps2_key;
                        BEEP=~BEEP;
                        switch(ps2_key)
                        {
                                case PSB_PAD_UP:kind = 1;break; 
                                case PSB_PAD_DOWN:kind = 2;break;
                                case PSB_PAD_LEFT:kind = 3;break;
                                case PSB_PAD_RIGHT:kind = 4;break;

                                case PSB_TRIANGLE:kind = 7;break;
                                case PSB_CROSS:kind = 8;break;
                                case PSB_PINK:kind = 9;break;
                                case PSB_CIRCLE:kind = 10;break;

                                case PSB_L1:kind = 6;break;
                                case PSB_L2:kind = 5;break;
                                case PSB_R1:kind = 12;break;
                                case PSB_R2:kind = 11;break;
                                default:break;
                        }
                                if (kind != 0)
                                {                
                                        flag_ps2_rev = 1;
                                        flag_connect = 1;
                                        SpiFlashRead(ps2_buf,(PS2_FLASH_ADDR)<<WRITE_BIT_DEPTH,sizeof(ps2_buf));
                                        sprintf(buf,"%dK",kind);
                                        //UART1_SendStr(buf);
                                        p = strstr(ps2_buf,buf);
                                        if (p != NULL)
                                        {
                                                p = p + strlen(buf);
                                                while(i < 14 && *p != 0)
                                                {
                                                        buf[i] = *p++;
                                                        i++;
                                                        if (*p == '#')
                                                                break;
                                                }
                                                if (i < 12)
                                                {
                                                        buf[i] = '\r';
                                                        buf[i+1] = '\n';
                                                        memcpy(redata,buf,sizeof(buf));
                                                        flag_RecFul = 1;
                                                }
                                                UART1_SendStr(redata);
                                        }
                                }
                        }
                else if(ps2_mode==1)//�̵�ģʽ
                {
                        switch(ps2_key)
                                {
                                        case PSB_PAD_UP:pwm[1]+=10;if(pwm[1]>=2300) pwm[1]=2300;break; 
                                        case PSB_PAD_DOWN:pwm[1]-=10;if(pwm[1]<=700) pwm[1]=700;break;
                                        case PSB_PAD_LEFT:pwm[2]+=10;if(pwm[2]>=2300) pwm[2]=2300;break;
                                        case PSB_PAD_RIGHT:pwm[2]-=10;if(pwm[2]<=700) pwm[2]=700;break;
                
                                        case PSB_TRIANGLE:pwm[3]+=10;if(pwm[3]>=2300) pwm[3]=2300;break; 
                                        case PSB_CROSS:pwm[3]-=10;if(pwm[3]<=700) pwm[3]=700;break;
                                        case PSB_PINK:pwm[4]+=10;if(pwm[4]>=2300) pwm[4]=2300;break; 
                                        case PSB_CIRCLE:pwm[4]-=10;if(pwm[4]<=700) pwm[4]=700;break;

                                        case PSB_L1:pwm[5]+=10;if(pwm[5]>=2300) pwm[5]=2300;break; 
                                        case PSB_L2:pwm[5]-=10;if(pwm[5]<=700)  pwm[5]=700;break;
                                        case PSB_R1:pwm[6]+=10;if(pwm[6]>=2300) pwm[6]=2300;break; 
                                        case PSB_R2:pwm[6]-=10;if(pwm[6]<=700)  pwm[6]=700;break;
                                        default:break;
                                }
                }
        }
}
      
void ReadMoterInfor()
{
        memset(&motor_data,0,sizeof(motor_data));//�� 0
        SpiFlashRead((char *)&motor_data,(CMD_FLASH_ADDR)<<WRITE_BIT_DEPTH,sizeof(motor_data));//��ȡ��Ϣ
        if (motor_data.CRC1 != 0x12345678 || motor_data.sum < 0 || motor_data.duoji_count  > MOTOR_NUM)//�ж���Ϣ�洢�Ƿ��д�
        {
                memset(&motor_data,0,sizeof(motor_data));
                //memset(&cur_item,0,sizeof(cur_item));
        }
        else//������Ϣ
        {
                //UART1_SendOneChar(motor_data.sum + 0x30);
                //cur_item.tuoji_count = motor_one_cmd.tuoji_count;//�ѻ����д���
                //cur_item.cur_num = 0;//�� 0
        }
                
}
void ReadOneCmdInfor(unsigned int addr)
{
        memset(&motor_one_cmd,0,sizeof(motor_one_cmd));//�� 0
        SpiFlashRead((char *)&motor_one_cmd,((((unsigned long)addr)<<4) + FILE_FLASH_ADDR)<<WRITE_BIT_DEPTH,sizeof(motor_one_cmd));//��ȡ��Ϣ
        if (motor_one_cmd.start >= motor_one_cmd.end || motor_one_cmd.cur_file_num != (addr) || motor_data.file_flag[motor_one_cmd.cur_file_num] == 0)//�ж���Ϣ�洢�Ƿ��д�
        {
                memset(&motor_one_cmd,0,sizeof(motor_one_cmd));
        }
        else//������Ϣ,�Ժ�������֤�õ�
        {
                
                
                cur_item.tuoji_count = motor_one_cmd.tuoji_count;//�ѻ����д���
                cur_item.cur_num = motor_one_cmd.start;
                //UART1_SendOneChar(motor_one_cmd.tuoji_count + 0x30);
                //cur_item.cur_num = 0;//�� 0
        }
                
}
      
void WriteMoterInfor()
{
        uchar temp = 0;
        motor_data.CRC1 = 0x12345678;//У����
        motor_data.duoji_count = MOTOR_NUM-1;
        temp = motor_data.filecount;
        SpiFlashEraseSector(CMD_FLASH_ADDR >> 4);//������ǰ�洢����Ϣ
        SpiFlashWrite((char *)&motor_data,CMD_FLASH_ADDR<<WRITE_BIT_DEPTH,sizeof(motor_data)); //д��flash
        ReadMoterInfor();
        if (temp != motor_data.filecount)
        {
                error |= ERROR_FLASH_WRITE;
        }
        else
        {
                error &= ~ERROR_FLASH_WRITE;
        }
}
void WriteOneCmdInfor(unsigned int addr)
{
        uchar temp = 0;
        temp = motor_one_cmd.end;
        if (((((unsigned long)addr)<<4) + FILE_FLASH_ADDR) % 16 == 0)
                SpiFlashEraseSector(((((unsigned long)addr)<<4) + FILE_FLASH_ADDR) >> 4);//������ǰ�洢����Ϣ
        SpiFlashWrite((char *)&motor_one_cmd,((((unsigned long)addr)<<4) + FILE_FLASH_ADDR)<<WRITE_BIT_DEPTH,sizeof(motor_one_cmd)); //д��flash
        ReadOneCmdInfor(addr);
        if (temp !=  motor_one_cmd.end)
        {
                error |= ERROR_FLASH_WRITE1;
        }
        else
        {
                error &= ~ERROR_FLASH_WRITE1;
        }
}
       
void GetOneMotorCMD()
{
#if DEBUG
        uchar buf[20] = {0};
#endif
        if (flag_stop_download)//���յ�����λ����ֹͣ���ص�����
        {
                flag_download = 0;//�������״̬��־λ
                flag_stop_download = 0;
                flag_read = 0;
                if (motor_data.filecount < MAX_SUPPORT_FILE_SAVE)
                {
                        updata_file_list();
                        motor_data.sum = motor_one_cmd.end;
                        motor_data.file_flag[motor_data.filecount] = 1;
                        motor_one_cmd.cur_file_num = file_last_num + 1;
                        motor_data.filecount = motor_one_cmd.cur_file_num + 1;
                        error &= ~MAX_SUPPORT_FILE_SAVE;
#if DEBUG
                        sprintf(buf,"%d %d\r\n",(uint)motor_data.filecount,(uint)motor_data.file_flag[motor_data.filecount-1]);
                        UART1_SendStr(buf);
#endif
                        WriteMoterInfor();
                        WriteOneCmdInfor(motor_one_cmd.cur_file_num);
                        updata_file_list();
#if DEBUG
                        
                        sprintf(buf,"%d %d\r\n",(uint)motor_data.filecount,(uint)motor_data.file_flag[motor_data.filecount-1]);
                        UART1_SendStr(buf);
#endif
                }
                else
                {
                        error |= MAX_SUPPORT_FILE_SAVE;
                }
                if        (!(error &(MAX_SUPPORT_FILE_SAVE | ERROR_FLASH_FULL)))
                        send_mode |= SEND_DOWN_OK;//״̬λ��Ϊ
        }
        if (flag_connect)//�����ǰ����λ������״̬
        {
                if (flag_read)//�����λ����ȡflash�ڴ洢����Ϣ
                {                
                        if (cur_item.cur_num < motor_one_cmd.end)//�ж��Ƿ񳬹�֮ǰ�洢����
                        {
                                if ((send_mode & SEND_SEND_FILE))//��ʼ���յ���ȡ������Ҫ�ȷ��͸�start
                                {
                                        UART1_SendStr("#Start\r\n");
                                        send_mode &= ~SEND_READ_FILE;
                                }
                                memset(redata,0,WRITE_SIZE);//�� 0
                                SpiFlashRead(redata,(((long)cur_item.cur_num)<<WRITE_BIT_DEPTH),WRITE_SIZE);//��ȡ��Ϣ
#if DEBUG
                                sprintf(buf,"%d\r\n",cur_item.cur_num);
                                UART1_SendStr(buf);
#endif
                                UART1_SendStr(redata);//����
                                cur_item.cur_num++;
                        }
                        else//����
                        {
                                if (cur_item.cur_num > 0)
                                        UART1_SendStr("#End\r\n");//���ͽ����ַ���
                                  flag_read = 0;
                        }
                        send_mode = 0;//�� 0
                }        
                if (flag_online_run)
                {
                        if ((send_mode & SEND_CC) != 0  || cur_item.cur_num == motor_one_cmd.start)//�����ǰ��Ҫ���¶������
                        {
                                if (cur_item.tuoji_count > 0)//�ѻ�����û����
                                {
                                        if (cur_item.cur_num < motor_one_cmd.end)//�ж��Ƿ��ȡ����
                                        {
                                                SpiFlashRead(redata,((long)cur_item.cur_num)<<WRITE_BIT_DEPTH,WRITE_SIZE);//��ȡ����
                                                flag_RecFul = 1;//��־λΪ1��
                                                cur_item.cur_num++;//
                                        }
                                        else//ִ����һ��
                                        {
                                                cur_item.cur_num = motor_one_cmd.start;
                                                cur_item.tuoji_count--;//��һ
                                        }
                                }
                                else//ִ�����
                                {
                                        flag_online_run = 0;
                                        if (flag_connect_run)//�����λ��ѡ��ִ�еĹ��ܣ���Ҫ���� AGF��Ϊ����
                                        {
                                                UART1_SendStr("#AGF\r\n");
                                                flag_connect_run = 0;
                                        }
                                }
                                //��ȡ����
                        }
                }
        } 
        else//�ѻ�
        {
                if (file_list_count < 0)
                {
                        return;
                }
                if (cur_item.tuoji_count > 0)
                {
                        if ((send_mode & SEND_CC) != 0  || cur_item.cur_num == motor_one_cmd.start)//�����ǰ��Ҫ���¶������
                        {
                                if (cur_item.cur_num < motor_one_cmd.end)//�ж��Ƿ��ȡ����
                                {
                                        SpiFlashRead(redata,((long)cur_item.cur_num)<<WRITE_BIT_DEPTH,WRITE_SIZE);//��ȡ����
                                        flag_RecFul = 1;//��־λΪ1��
                                        cur_item.cur_num++;//
                                }
                                else//ִ����һ��
                                {
                                        cur_item.cur_num = motor_one_cmd.start;
                                        cur_item.tuoji_count--;//��һ
                                }
                                //��ȡ����
                        }
                }
                else
                {
                        ReadOneCmdInfor(file_list[cur_item.file_num]);
                        file_list_count--;
                        cur_item.file_num++;
                }
        }
                
        
}
     
void SendUartState()
{
        uchar buf[40] = {0};
        uchar read_motor_num = 0;
        uint i = 0;
        static int count = 0;
        if (send_mode)//�����״̬��Ҫ����
        {
                if (send_mode & SEND_A) //����A
                {
                        UART1_SendOneChar('A');
                        send_mode &= ~SEND_A;//��״̬
                }
                if (send_mode & SEND_CC) //����CC
                {
                        UART1_SendStr("#CC\r\n");
                        send_mode &= ~SEND_CC;
                }
                if (send_mode & SEND_DOWN_OK)//��������ok��״̬�ַ���
                {
                        sprintf(buf,"#Down+OK+%d\r\n",(int)motor_data.filecount-1);
                        UART1_SendStr(buf);
                        send_mode &= ~SEND_DOWN_OK;
#if DEBUG
                        sprintf(buf,"%d\r\n",(uint)motor_data.filecount);
                        UART1_SendStr(buf);
#endif
                }
                if (send_mode & SEND_START_OK)//��������ʱ����ַ���
                {
                        UART1_SendStr("#Veri+UART+OK+20160906+176\r\n");
                        send_mode &= ~SEND_START_OK;
                }
                if (send_mode & SEND_READ_FILE)//���Ͷ�ȡ�ļ���ʱ���ַ���
                {
                        if (motor_data.filecount > 0)//���������ж������
                        {
                                //#Name:1.txt--Size:48--Name:2.txt--Size:190--Name:desktop.ini--Size:531--
                                UART1_SendStr("#");//����
                                for (i = 0; i < motor_data.filecount;i++)
                                {
                                        if (motor_data.file_flag[i] == 1)
                                        {
                                                ReadOneCmdInfor(i);
                                                if (motor_one_cmd.end - motor_one_cmd.start <= 0)
                                                {
                                                        motor_data.file_flag[i] = 0;
                                                        WriteMoterInfor();
#if DEBUG
                                                        sprintf(buf,"E=%d S=%d",motor_one_cmd.end, motor_one_cmd.start);
#endif
                                                }
                                                else
                                                {
                                                        sprintf(buf,"Name:%d.txt--Size:%d--",i,motor_one_cmd.end - motor_one_cmd.start);//��ȡ�������
                                                        UART1_SendStr(buf);//����
                                                }
                                        }

                                }
                                UART1_SendStr("\r\n");                                
                        }
                        else
                        {
                                sprintf(buf,"#\r\n",motor_data.sum);
                                UART1_SendStr(buf);
                        }
                        send_mode &= ~SEND_READ_FILE;
                }
                if (send_mode & SEND_SET_OFFLINE_OK)//�����ѻ����д���
                {
                        WriteOneCmdInfor(motor_one_cmd.cur_file_num);//����
                        UART1_SendStr("#Enable+OK...\r\n");
                        send_mode &= ~SEND_SET_OFFLINE_OK;
                }
                if (send_mode & SEND_SET_DISABLEOFFLINE_OK)//��ֹ�ѻ�����
                {
                        for (i = 0; i < motor_data.filecount;i++)
                        {
                                if (motor_data.file_flag[i] == 1)
                                {
                                        ReadOneCmdInfor(i);
                                        motor_one_cmd.tuoji_count = 0;
                                        WriteOneCmdInfor(i);
                                }

                        }
                        WriteMoterInfor();
                        UART1_SendStr("#Disable+OK...\r\n");
                        send_mode &= ~SEND_SET_DISABLEOFFLINE_OK;
                }
                if (send_mode & SEND_SET_ONLINE_OK)//������������״̬
                {
                        UART1_SendStr("#OK\r\n");
                        sprintf(buf,"#%dGC%d\r\n",cur_item.file_num,tuoji_count);
                        UART1_SendStr(buf);
                        UART1_SendStr("#LP=0\r\n");
                        send_mode &= ~SEND_SET_ONLINE_OK;
                        flag_connect_run = 1;
                }
                if (send_mode & SEND_SET_DELETE_ONE_FILE_OK)//����ɾ���ļ�����
                {
                        //cur_item.tuoji_count = 0;
                        if (cur_item.delete_num < motor_data.filecount)
                        {
                                motor_data.file_flag[cur_item.delete_num] = 0;
                                WriteMoterInfor();
                                updata_file_list();
                                if (cur_item.delete_num  == motor_data.filecount-1)
                                {
                                        motor_data.filecount = file_last_num + 1; 
                                        if (file_last_num == -1)
                                        {
                                                motor_data.sum = 0;
                                        }
                                        else
                                        {
                                                ReadOneCmdInfor(file_last_num);
                                                motor_data.sum = motor_one_cmd.end;
                                                motor_data.sum = (((long int)(motor_data.sum) >>4)<<4) + (1<<4);
                                        }
                                        WriteMoterInfor();
                                }
                                updata_file_list();                
                                UART1_SendStr("#FDel+OK\r\n");
                        }
                        send_mode &= ~SEND_SET_DELETE_ONE_FILE_OK;
                        
                }
                if (send_mode & SEND_SET_DELETE_ALL_FILE_OK)//���Ͳ��������ļ�������
                {
                        UART1_SendStr("#Format+Start\r\n");
                        SpiFlashEraseChip();
                        cur_item.tuoji_count = 0;
                        motor_data.sum = 0;
                        motor_data.filecount = 0;
                        memset(motor_data.file_flag,0,sizeof(motor_data.file_flag));
                        WriteMoterInfor();
                        UART1_SendStr("#Format+OK\r\n");
                        send_mode &= ~SEND_SET_DELETE_ALL_FILE_OK;
                        updata_file_list();
                }
                if (send_mode & SEND_SET_PS2_OK)
                {
                        UART1_SendStr("#PS2+OK...\r\n");
                        send_mode &= ~SEND_SET_PS2_OK;
                }
                
#define MATHION_HAND_NUM 20
                if (send_mode & SEND_SET_READ_UART_MOTOR_ANGLE)
                {
                        if (cur_item.read_num < MATHION_HAND_NUM)
                        {
                                if (flag_uart2_rev)
                                {
                                        read_motor_num = atoi(uart2_buf + 1);
                                        if (read_motor_num == cur_item.read_num)
                                        {
                                                i = atoi(uart2_buf+5);
                                                sprintf(uart2_buf,"#%dP%d",(int)read_motor_num,i);
                                                UART1_SendStr(uart2_buf);
                                                cur_item.read_num++;
                                                buf[0] = '#';
                                                buf[1] = cur_item.read_num / 100 % 10 + 0x30;
                                                buf[2] = cur_item.read_num / 10 % 10 + 0x30;
                                                buf[3] = cur_item.read_num % 10 + 0x30;
                                                buf[4] = 'P';buf[5] = 'R';buf[6] = 'A';buf[7] = 'D';buf[8] = '\r';buf[9] = '\n';
                                                UART2_SendStr(buf);
                                                
                                        }
                                        flag_uart2_rev = 0;
                                        count = 0;
                                        
                                }
                                else
                                {
                                        count++;
                                        if (count >= 10)
                                        {
                                                cur_item.read_num++;
                                                buf[0] = '#';
                                                buf[1] = cur_item.read_num / 100 % 10 + 0x30;
                                                buf[2] = cur_item.read_num / 10 % 10 + 0x30;
                                                buf[3] = cur_item.read_num % 10 + 0x30;
                                                buf[4] = 'P';buf[5] = 'R';buf[6] = 'A';buf[7] = 'D';buf[8] = '\r';buf[9] = '\n';
                                                UART2_SendStr(buf);
                                                flag_uart2_rev = 0;
                                                flag_uart2_rev_time_out = 0;
                                                count = 0;
                                        }
                                }
                        }
                        else
                        {
                                send_mode &= ~SEND_SET_READ_UART_MOTOR_ANGLE;
                                cur_item.read_num= 0;
                                UART1_SendStr("\r\n");
                        }
                }
        }
        if (send_mode & SEND_SET_SET_UART_MOTOR_PULK)
        {
                if (cur_item.pulk_num < MATHION_HAND_NUM)
                {
                        count++;
                        if (count >= 20)
                        {
                                sprintf(uart2_buf,"#%dPULK\r\n",(int)cur_item.pulk_num);
                                UART2_SendStr(uart2_buf);
#if DEBUG
                                UART1_SendStr(uart2_buf);
#endif
                                cur_item.pulk_num++;
                                count = 0;
                        }
                }
                else
                {
                        send_mode &= ~SEND_SET_SET_UART_MOTOR_PULK;
                }
        }
        if (send_mode & SEND_SET_SET_UART_MOTOR_ANGLE)
        {
                if (cur_item.pulk_num < MATHION_HAND_NUM)
                {
                        count++;
                        if (count >= 5)
                        {
                                sprintf(uart2_buf,"#%dPMOD%d\r\n",(int)cur_item.pulk_num,(int)cur_item.angle_mode);
                                UART2_SendStr(uart2_buf);
#if DEBUG
                                UART1_SendStr(uart2_buf);
#endif
                                cur_item.pulk_num++;
                                count = 0;
                        }
                }
                else
                {
                        sprintf(buf,"#255PMOD%d+0K...\r\n",(int)cur_item.angle_mode);
                        UART1_SendStr(buf);
                        send_mode &= ~SEND_SET_SET_UART_MOTOR_ANGLE;
                        flag_uart2_rev = 0;
                }
        }
        if (send_mode & SEND_SET_BEEP_ON)
        {
                ReadMoterInfor();
                motor_data.beep_mode = 1;
                beep_mode = 1;
                WriteMoterInfor();
                UART1_SendStr("#FMQENABLE+OK...\r\n");
                send_mode &= ~SEND_SET_BEEP_ON;
        }
        if (send_mode & SEND_SET_BEEP_OFF)
        {
                ReadMoterInfor();
                motor_data.beep_mode = 0;
                beep_mode = 0;
                WriteMoterInfor();
                UART1_SendStr("#FMQDISABLE+OK...\r\n");
                send_mode &= ~SEND_SET_BEEP_OFF;
        }                
}

      
 void change(void)
{        
        uchar s;
        if(line>0)                                   //������������
        {  
                line--;                                   //ִ��һ��
                if(line<5)                        //�������������µ�����                        
                        flag_in=1;
                point_now++;                //ȡ��λ�ø���
                point_aim++;
                
                if(point_aim==7)
                           point_aim=0;
                if(point_now==7)
                           point_now=0;
                n=pos[point_aim][0]*4/5;        //�����µĲ岹����
                for(s=1;s<MOTOR_NUM;s++)        //�����µĲ岹����
                {
                 if(pos[point_aim][s]>pos[point_now][s])
                        {
                                   dp=pos[point_aim][s]-pos[point_now][s];
                                   dp0[s]=dp/n;
                        }
                    if(pos[point_aim][s]<=pos[point_now][s])
                        {
                                dp=pos[point_now][s]-pos[point_aim][s];
                                dp0[s]=dp/n;
                                dp0[s]=-dp0[s];
                        }
           }
                m=0;                                          //m��0
                flag_stop=0;                          //�������µ�Ŀ��λ�ã�ֹͣ��־����
                
        }
        else                                                  //û�л������ݣ���line==0
        {
                flag_out=0;                                //������û������
        }
}
    
void vpwm(void)                 
{
        uchar j=0;
        uchar how=0;
  static uchar flag_how;
        static uchar flag_Tover;

        if(flag_stop==1)                                           //һ����ҵȫ�����
        {        
                if(flag_out==1)                                         //����������������
                {
                        change();                                        //������
                }
        }
        else                                                                //����һ������ȫ����ɣ������м�岹�׶�
        {
                m++;                                                        //�����ۼӲ岹���Ĵ���
                if(m==n)                                                //n�Ǳ�����ҵҪ�岹���ܴ���
                {
                  flag_Tover=1;                                //һ�����ݵ�ִ��ʱ���Ѿ����
                        send_mode |= SEND_CC;
                }
                for(j=1;j<MOTOR_NUM;j++)
                {
                        if(abs(pwm[j]-pos[point_aim][j])<5)
                        {                                                           //��⿿���յ�λ��
                           how++;                                           //�ǣ����ۼ�һ��
                           pwm[j]=pos[point_aim][j];//����ֱ�ӹ��ȵ��յ�λ��
                        }        
                        else                                                //�������յ㣬�����岹
                                pwm[j]=pos[point_now][j]+m*dp0[j];
                }         
                //UART_Put_Inf("pwm",pwm[1]);
                if(how==MOTOR_NUM-1)
                        flag_how=1;                                                  //16������������յ�
                how=0; 
                if((flag_Tover==1)&&(flag_how==1))
                {                                                                //�Ӳ岹���������������������涼�����յ㣬����ҵ�����
                         flag_Tover=0;
                         flag_how=0;
                         flag_stop=1;
                }
                
         }
        return;

}

                           