#include "delay.h"
#include "common.h"
void delayms(unsigned int xms)	 //???????
 {
   uint i = 0,j = 0;
	 xms = xms << 1;
   for(i=xms;i>0;i--)
      for(j=1700;j>0;j--);
 }
void delay(unsigned int n) 		  //???????
{
	uint i;
	n = n <<1;
	for(i=0;i<=n;i++)       
		_nop_();
		_nop_();	
		_nop_();
		_nop_();
		_nop_();
		_nop_();
		_nop_();
		_nop_();	
		_nop_();
		_nop_();
		_nop_();
		_nop_();
		_nop_();
		_nop_();	
		_nop_();		
}