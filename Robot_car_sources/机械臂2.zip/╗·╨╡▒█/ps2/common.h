#ifndef __COMMON_H__
#define __COMMON_H__
#include "STC15Fxxxx.h"
#include<intrins.h>
#define  uint unsigned int 
#define  uchar unsigned char 
#endif