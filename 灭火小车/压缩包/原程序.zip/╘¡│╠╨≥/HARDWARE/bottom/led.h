#ifndef __LED_H
#define __LED_H	 
#include "sys.h" 

//LED�˿ڶ���
#define LED0 PEout(3)	// LED0
#define LED1 PEout(4)	// LED1	 


//LED�Ƴ�ʼ��	
void LED_Init(void);

#endif


