#ifndef DEMO_DIO
#define DEMO_DIO

#include "DIO.h"
#include "driver.h"

#define Gray1	PDin(2) //�Ҷ�1���� ETR3
#define Gray2 	PEin(0)	//�Ҷ�2���� ETR1

#define I_DIO1 PDin(11)	//����DIO1			1
#define I_DIO2 PDin(7)	//����DIO2			2
#define I_DIO3 PFin(7)	//����DIO3			3
#define I_DIO4 PFin(8)	//����DIO4			4
#define I_PWM5 PCin(6)	//����PWM5			5
#define I_PWM6 PCin(7)	//����PWM6			6
#define I_PWM7 PCin(8)	//����PWM7			7
#define I_ETR4 PAin(12)	//����ETR4			8

u8 Flase_Angle(u16 goal_Angle,float sta_FalseAngle);
void gostr_usix(int goal_Angle,int speed);
void Infrared_Run(u8 speed,int engine);
void Infrared_R_Turn(u8 speed,int angle,int engine,int slow);
void Infrared_L_Turn(u8 speed,int angle,int engine,int slow);
void Infrared_R_Turn1(u8 speed,int angle,int engine,int slow);
void Infrared_L_Turn1(u8 speed,int angle,int engine,int slow);
void Infrared_R_Turn2(u8 speed,int angle,int engine,int slow);
void Infrared_L_Turn2(u8 speed,int angle,int engine,int slow);
void Infrared_L_Turn1(u8 speed,int angle,int engine,int slow);
void Infrared_R_Turn3(u8 speed,int angle,int engine,int slow);
void Infrared_L_Turn3(u8 speed,int angle,int engine,int slow);
void gostraight(u8 speed,int angle,int engine,int slow);
void hy(u8 speed,int engine,int slow);
void Infrared_L_Turn4(int angle);
void Infrared_R_Turn4(int angle);
int scanf_blaze(float angle,int door);
void Hunt_door(u8 speed,float angle);
void start1();
void start2();
void start3();
void start4();
void Back_home1();
void Back_home2();
void Back_home3();
void Back_home4();
void Accident();

#endif

