#include "demo_DIO.h"
#include "beep.h"
#include "delay.h"
#include "usart.h"
#include "usart3.h"	 
#include "led.h"
#include "wt61.h"
#include "drive.h"
#include "math.h"
#include "fan.h"
#include "sys.h"

int flag;
float angle;//��¼���뷿��ǰת�ĽǶ�

/*
*********************************************************************************************************
*	�� �� ��: Infrared_L_Turn
*	����˵��: ������ǰ����ת�����
*	��    ��: speed�����ٶ� angle�����Ƕ� engine������ͷ
*	�� �� ֵ:��
*********************************************************************************************************
*/
void Infrared_L_Turn(u8 speed,int angle,int engine,int slow)
{
	while(1)
	{
			if(engine==0)
			{
					if((abs(angle-Get_Angle())>0&&abs(angle-Get_Angle())<5))
					{				
						CarAdvance(0);
						break;
					}
					else if(abs(angle-Get_Angle())>4&&abs(angle-Get_Angle())<14)
					{
						SetLeftWhell(0,(speed-5*slow)/100);SetRightWhell(0,speed-5*slow); //???
					}
					else if(abs(angle-Get_Angle())>14&&abs(angle-Get_Angle())<24)
					{
						SetLeftWhell(0,(speed-4*slow)/100);SetRightWhell(0,speed-4*slow); //???
					}
					else if(abs(angle-Get_Angle())>24&&abs(angle-Get_Angle())<34)
					{
						SetLeftWhell(0,(speed-3*slow)/100);SetRightWhell(0,speed-3*slow); //???
					}
					else if(abs(angle-Get_Angle())>34&&abs(angle-Get_Angle())<44)
					{
						SetLeftWhell(0,(speed-2*slow)/100);SetRightWhell(0,speed-2*slow); //???
					}
					else if(abs(angle-Get_Angle())>44&&abs(angle-Get_Angle())<54)
					{
						SetLeftWhell(0,(speed-1*slow)/100);SetRightWhell(0,speed-1*slow); //???
					}
					else
					{
						SetLeftWhell(0,speed/2);SetRightWhell(0,speed);
					}			
			}
		else if(engine==1)
		{
			if((abs(angle-Get_Angle())>0&&abs(angle-Get_Angle())<5))
					{				
						CarRetreat(0);
						break;
					}
					else if(abs(angle-Get_Angle())>4&&abs(angle-Get_Angle())<14)
					{
						SetLeftWhell(1,(speed-5*slow)/100);SetRightWhell(1,speed-5*slow); //???
					}
					else if(abs(angle-Get_Angle())>14&&abs(angle-Get_Angle())<24)
					{
						SetLeftWhell(1,(speed-4*slow)/100);SetRightWhell(1,speed-4*slow); //???
					}
					else if(abs(angle-Get_Angle())>24&&abs(angle-Get_Angle())<34)
					{
						SetLeftWhell(1,(speed-3*slow)/100);SetRightWhell(1,speed-3*slow); //???
					}
					else if(abs(angle-Get_Angle())>34&&abs(angle-Get_Angle())<44)
					{
						SetLeftWhell(1,(speed-2*slow)/100);SetRightWhell(1,speed-2*slow); //???
					}
					else if(abs(angle-Get_Angle())>44&&abs(angle-Get_Angle())<54)
					{
						SetLeftWhell(1,(speed-1*slow)/100);SetRightWhell(1,speed-1*slow); //???
					}
					else
					{
						SetLeftWhell(1,speed/2);SetRightWhell(1,speed);
					}			
		}
	}
}


/*
*********************************************************************************************************
*	�� �� ��: Infrared_R_Turn5
*	����˵��: �����Һ󻡶�
*	��    ��: speed�����ٶ� angle�����Ƕ� engine������ͷ
*	�� �� ֵ:��
*********************************************************************************************************
*/
void Infrared_R_Turn5(u8 speed,int angle,int engine,int slow)
{
	while(1)
	{
			if(engine==1)
			{
					if((abs(angle-Get_Angle())>0&&abs(angle-Get_Angle())<5))
					{				
						Stop();
						break;
					}
					else if(abs(angle-Get_Angle())>4&&abs(angle-Get_Angle())<14)
					{
						SetLeftWhell(0,speed-5*slow);SetRightWhell(0,(speed-5*slow)/5); //???
					}
					else if(abs(angle-Get_Angle())>14&&abs(angle-Get_Angle())<24)
					{
						SetLeftWhell(0,speed-4*slow);SetRightWhell(0,(speed-4*slow)/5); //???
					}
					else if(abs(angle-Get_Angle())>24&&abs(angle-Get_Angle())<34)
					{
						SetLeftWhell(0,speed-3*slow);SetRightWhell(0,(speed-3*slow)/20); //???
					}
					else if(abs(angle-Get_Angle())>34&&abs(angle-Get_Angle())<44)
					{
						SetLeftWhell(0,speed-2*slow);SetRightWhell(0,(speed-2*slow)/50); //???
					}
					else if(abs(angle-Get_Angle())>44&&abs(angle-Get_Angle())<54)
					{
						SetLeftWhell(0,speed-1*slow);SetRightWhell(0,(speed-1*slow)/100); //???
					}
					else
					{
						SetLeftWhell(0,speed);SetRightWhell(0,speed/3);
					}			
			}
	}
}
/*
*********************************************************************************************************
*	�� �� ��: Infrared_R_Turn5_2
*	����˵��: �����Һ󻡶�
*	��    ��: speed�����ٶ� angle�����Ƕ� engine������ͷ
*	�� �� ֵ:��
*********************************************************************************************************
*/
void Infrared_R_Turn5_2(u8 speed,int angle,int engine,int slow)
{
	while(1)
	{
			if(engine==1)
			{
					if((abs(angle-Get_Angle())>0&&abs(angle-Get_Angle())<5))
					{				
						Stop();
						break;
					}
					else if(abs(angle-Get_Angle())>4&&abs(angle-Get_Angle())<14)
					{
						SetLeftWhell(0,speed-5*slow);SetRightWhell(0,(speed-5*slow)/5); //???
					}
					else if(abs(angle-Get_Angle())>14&&abs(angle-Get_Angle())<24)
					{
						SetLeftWhell(0,speed-4*slow);SetRightWhell(0,(speed-4*slow)/20); //???
					}
					else if(abs(angle-Get_Angle())>24&&abs(angle-Get_Angle())<34)
					{
						SetLeftWhell(0,speed-3*slow);SetRightWhell(0,(speed-3*slow)/50); //???
					}
					else if(abs(angle-Get_Angle())>34&&abs(angle-Get_Angle())<44)
					{
						SetLeftWhell(0,speed-2*slow);SetRightWhell(0,(speed-2*slow)/50); //???
					}
					else if(abs(angle-Get_Angle())>44&&abs(angle-Get_Angle())<54)
					{
						SetLeftWhell(0,speed-1*slow);SetRightWhell(0,(speed-1*slow)/100); //???
					}
					else
					{
						SetLeftWhell(0,speed);SetRightWhell(0,speed/2);
					}			
			}
	}
}
/*
*********************************************************************************************************
*	�� �� ��: Infrared_R_Turn5_3
*	����˵��: �����Һ󻡶�
*	��    ��: speed�����ٶ� angle�����Ƕ� engine������ͷ
*	�� �� ֵ:��
*********************************************************************************************************
*/
void Infrared_R_Turn5_3(u8 speed,int angle,int engine,int slow)
{
	while(1)
	{
			if(engine==1)
			{
					if((abs(angle-Get_Angle())>0&&abs(angle-Get_Angle())<5))
					{				
						Stop();
						break;
					}
					else if(abs(angle-Get_Angle())>4&&abs(angle-Get_Angle())<14)
					{
						SetLeftWhell(0,speed-5*slow);SetRightWhell(0,(speed-5*slow)/5); //???
					}
					else if(abs(angle-Get_Angle())>14&&abs(angle-Get_Angle())<24)
					{
						SetLeftWhell(0,speed-4*slow);SetRightWhell(0,(speed-4*slow)/5); //???
					}
					else if(abs(angle-Get_Angle())>24&&abs(angle-Get_Angle())<34)
					{
						SetLeftWhell(0,speed-3*slow);SetRightWhell(0,(speed-3*slow)/20); //???
					}
					else if(abs(angle-Get_Angle())>34&&abs(angle-Get_Angle())<44)
					{
						SetLeftWhell(0,speed-2*slow);SetRightWhell(0,(speed-2*slow)/50); //???
					}
					else if(abs(angle-Get_Angle())>44&&abs(angle-Get_Angle())<54)
					{
						SetLeftWhell(0,speed-1*slow);SetRightWhell(0,(speed-1*slow)/100); //???
					}
					else
					{
						SetLeftWhell(1,speed/8);SetRightWhell(0,speed);
					}			
			}
	}
}
/*
*********************************************************************************************************
*	�� �� ��: Infrared_R_Turn5_4
*	����˵��: �����Һ󻡶�
*	��    ��: speed�����ٶ� angle�����Ƕ� engine������ͷ
*	�� �� ֵ:��
*********************************************************************************************************
*/
void Infrared_R_Turn5_4(u8 speed,int angle,int engine,int slow)
{
	while(1)
	{
			if(engine==1)
			{
					if((abs(angle-Get_Angle())>0&&abs(angle-Get_Angle())<5))
					{				
						Stop();
						break;
					}
					else if(abs(angle-Get_Angle())>4&&abs(angle-Get_Angle())<14)
					{
						SetLeftWhell(0,speed-5*slow);SetRightWhell(0,(speed-5*slow)/5); //???
					}
					else if(abs(angle-Get_Angle())>14&&abs(angle-Get_Angle())<24)
					{
						SetLeftWhell(0,speed-4*slow);SetRightWhell(0,(speed-4*slow)/20); //???
					}
					else if(abs(angle-Get_Angle())>24&&abs(angle-Get_Angle())<34)
					{
						SetLeftWhell(0,speed-3*slow);SetRightWhell(0,(speed-3*slow)/50); //???
					}
					else if(abs(angle-Get_Angle())>34&&abs(angle-Get_Angle())<44)
					{
						SetLeftWhell(0,speed-2*slow);SetRightWhell(0,(speed-2*slow)/50); //???
					}
					else if(abs(angle-Get_Angle())>44&&abs(angle-Get_Angle())<54)
					{
						SetLeftWhell(0,speed-1*slow);SetRightWhell(0,(speed-1*slow)/100); //???
					}
					else
					{
						SetLeftWhell(0,speed);SetRightWhell(0,speed/4);
					}			
			}
	}
}
/*
*********************************************************************************************************
*	�� �� ��: Infrared_L_Turn6
*	����˵��: ������󻡶�
*	��    ��: speed�����ٶ� angle�����Ƕ� engine������ͷ
*	�� �� ֵ:��
*********************************************************************************************************
*/
void Infrared_L_Turn6(u8 speed,int angle,int engine,int slow)
{
	while(1)
	{
			if(engine==1)
			{
					if((abs(angle-Get_Angle())>0&&abs(angle-Get_Angle())<5))
					{				
						Stop();
						break;
					}
					else if(abs(angle-Get_Angle())>4&&abs(angle-Get_Angle())<14)
					{
						SetLeftWhell(1,(speed-1*slow)/100);SetRightWhell(1,speed-1*slow); //???
					}
					else if(abs(angle-Get_Angle())>14&&abs(angle-Get_Angle())<24)
					{
						SetLeftWhell(1,(speed-1*slow)/100);SetRightWhell(1,speed-4*slow); //???
					}
					else if(abs(angle-Get_Angle())>24&&abs(angle-Get_Angle())<34)
					{
						SetLeftWhell(1,(speed-1*slow)/100);SetRightWhell(1,speed-3*slow); //???
					}
					else if(abs(angle-Get_Angle())>34&&abs(angle-Get_Angle())<44)
					{
						SetLeftWhell(1,(speed-1*slow)/100);SetRightWhell(1,speed-2*slow); //???
					}
					else if(abs(angle-Get_Angle())>44&&abs(angle-Get_Angle())<54)
					{
						SetLeftWhell(1,(speed-1*slow)/100);SetRightWhell(1,speed-1*slow); //???
					}
					else
					{
						SetLeftWhell(1,speed/2);SetRightWhell(1,speed);
					}			
			}
	}
}
/*
*********************************************************************************************************
*	�� �� ��: Infrared_L_Turn6_2
*	����˵��: ������󻡶�
*	��    ��: speed�����ٶ� angle�����Ƕ� engine������ͷ
*	�� �� ֵ:��
*********************************************************************************************************
*/
void Infrared_L_Turn6_2(u8 speed,int angle,int engine,int slow)
{
	while(1)
	{
			if(engine==1)
			{
					if((abs(angle-Get_Angle())>0&&abs(angle-Get_Angle())<5))
					{				
						Stop();
						break;
					}
					else if(abs(angle-Get_Angle())>4&&abs(angle-Get_Angle())<14)
					{
						SetLeftWhell(1,(speed-1*slow)/100);SetRightWhell(1,speed-5*slow); //???
					}
					else if(abs(angle-Get_Angle())>14&&abs(angle-Get_Angle())<24)
					{
						SetLeftWhell(1,(speed-1*slow)/100);SetRightWhell(1,speed-4*slow); //???
					}
					else if(abs(angle-Get_Angle())>24&&abs(angle-Get_Angle())<34)
					{
						SetLeftWhell(1,(speed-1*slow)/100);SetRightWhell(1,speed-3*slow); //???
					}
					else if(abs(angle-Get_Angle())>34&&abs(angle-Get_Angle())<44)
					{
						SetLeftWhell(1,(speed-1*slow)/100);SetRightWhell(1,speed-2*slow); //???
					}
					else if(abs(angle-Get_Angle())>44&&abs(angle-Get_Angle())<54)
					{
						SetLeftWhell(1,(speed-1*slow)/100);SetRightWhell(1,speed-1*slow); //???
					}
					else
					{
						SetLeftWhell(1,2*speed/3);SetRightWhell(1,speed);
					}			
			}
	}
}
/*
*********************************************************************************************************
*	�� �� ��: Infrared_L_Turn7
*	����˵��: ������ǰ����
*	��    ��: speed�����ٶ� angle�����Ƕ� engine������ͷ
*	�� �� ֵ:��
*********************************************************************************************************
*/
void Infrared_L_Turn7(u8 speed,int angle,int engine,int slow)
{
	while(1)
	{
			if(engine==0)
			{
					if((abs(angle-Get_Angle())>0&&abs(angle-Get_Angle())<5))
					{				
						Stop();
						break;
					}
					else if(abs(angle-Get_Angle())>4&&abs(angle-Get_Angle())<14)
					{
						SetLeftWhell(0,(speed-5*slow)/5);SetRightWhell(0,speed-5*slow); //???
					}
					else if(abs(angle-Get_Angle())>14&&abs(angle-Get_Angle())<24)
					{
						SetLeftWhell(0,(speed-4*slow)/20);SetRightWhell(0,speed-4*slow); //???
					}
					else if(abs(angle-Get_Angle())>24&&abs(angle-Get_Angle())<34)
					{
						SetLeftWhell(0,(speed-3*slow)/50);SetRightWhell(0,speed-3*slow); //???
					}
					else if(abs(angle-Get_Angle())>34&&abs(angle-Get_Angle())<44)
					{
						SetLeftWhell(0,(speed-2*slow)/100);SetRightWhell(0,speed-2*slow); //???
					}
					else if(abs(angle-Get_Angle())>44&&abs(angle-Get_Angle())<54)
					{
						SetLeftWhell(0,(speed-1*slow)/100);SetRightWhell(0,speed-1*slow); //???
					}
					else
					{
						SetLeftWhell(0,speed/3);SetRightWhell(0,speed);
					}			
			}
	}
}
/*
*********************************************************************************************************
*	�� �� ��: Infrared_L_Turn7_2
*	����˵��: ������ǰ����
*	��    ��: speed�����ٶ� angle�����Ƕ� engine������ͷ
*	�� �� ֵ:��
*********************************************************************************************************
*/
void Infrared_L_Turn7_2(u8 speed,int angle,int engine,int slow)
{
	while(1)
	{
			if(engine==0)
			{
					if((abs(angle-Get_Angle())>0&&abs(angle-Get_Angle())<5))
					{				
						Stop();
						break;
					}
					else if(abs(angle-Get_Angle())>4&&abs(angle-Get_Angle())<14)
					{
						SetLeftWhell(0,(speed-5*slow)/5);SetRightWhell(0,speed-5*slow); //???
					}
					else if(abs(angle-Get_Angle())>14&&abs(angle-Get_Angle())<24)
					{
						SetLeftWhell(0,(speed-4*slow)/20);SetRightWhell(0,speed-4*slow); //???
					}
					else if(abs(angle-Get_Angle())>24&&abs(angle-Get_Angle())<34)
					{
						SetLeftWhell(0,(speed-3*slow)/50);SetRightWhell(0,speed-3*slow); //???
					}
					else if(abs(angle-Get_Angle())>34&&abs(angle-Get_Angle())<44)
					{
						SetLeftWhell(0,(speed-2*slow)/100);SetRightWhell(0,speed-2*slow); //???
					}
					else if(abs(angle-Get_Angle())>44&&abs(angle-Get_Angle())<54)
					{
						SetLeftWhell(0,(speed-1*slow)/100);SetRightWhell(0,speed-1*slow); //???
					}
					else
					{
						SetLeftWhell(0,2*speed/3);SetRightWhell(0,speed);
					}			
			}
	}
}
/*
*********************************************************************************************************
*	�� �� ��: Infrared_L_Turn7_3
*	����˵��: ������ǰ����
*	��    ��: speed�����ٶ� angle�����Ƕ� engine������ͷ
*	�� �� ֵ:��
*********************************************************************************************************
*/
void Infrared_L_Turn7_3(u8 speed,int angle,int engine,int slow)
{
	while(1)
	{
			if(engine==0)
			{
					if((abs(angle-Get_Angle())>0&&abs(angle-Get_Angle())<5))
					{				
						Stop();
						break;
					}
					else if(abs(angle-Get_Angle())>4&&abs(angle-Get_Angle())<14)
					{
						SetLeftWhell(0,(speed-5*slow)/5);SetRightWhell(0,speed-5*slow); //???
					}
					else if(abs(angle-Get_Angle())>14&&abs(angle-Get_Angle())<24)
					{
						SetLeftWhell(0,(speed-4*slow)/20);SetRightWhell(0,speed-4*slow); //???
					}
					else if(abs(angle-Get_Angle())>24&&abs(angle-Get_Angle())<34)
					{
						SetLeftWhell(0,(speed-3*slow)/50);SetRightWhell(0,speed-3*slow); //???
					}
					else if(abs(angle-Get_Angle())>34&&abs(angle-Get_Angle())<44)
					{
						SetLeftWhell(0,(speed-2*slow)/100);SetRightWhell(0,speed-2*slow); //???
					}
					else if(abs(angle-Get_Angle())>44&&abs(angle-Get_Angle())<54)
					{
						SetLeftWhell(0,(speed-1*slow)/100);SetRightWhell(0,speed-1*slow); //???
					}
					else
					{
						SetLeftWhell(0,speed/8);SetRightWhell(0,speed);
					}			
			}
	}
}
/*
*********************************************************************************************************
*	�� �� ��: Infrared_R_Turn8
*	����˵��: ������ǰ����
*	��    ��: speed�����ٶ� angle�����Ƕ� engine������ͷ
*	�� �� ֵ:��
*********************************************************************************************************
*/
void Infrared_R_Turn8(u8 speed,int angle,int engine,int slow)
{
	while(1)
	{
			if(engine==0)
			{
					if((abs(angle-Get_Angle())>0&&abs(angle-Get_Angle())<5))
					{				
						Stop();
						break;
					}
					else if(abs(angle-Get_Angle())>4&&abs(angle-Get_Angle())<14)
					{
						SetLeftWhell(1,speed-5*slow);SetRightWhell(1,(speed-5*slow)/5); //???
					}
					else if(abs(angle-Get_Angle())>14&&abs(angle-Get_Angle())<24)
					{
						SetLeftWhell(1,speed-4*slow);SetRightWhell(1,(speed-4*slow)/20); //???
					}
					else if(abs(angle-Get_Angle())>24&&abs(angle-Get_Angle())<34)
					{
						SetLeftWhell(1,speed-3*slow);SetRightWhell(1,(speed-3*slow)/50); //???
					}
					else if(abs(angle-Get_Angle())>34&&abs(angle-Get_Angle())<44)
					{
						SetLeftWhell(1,speed-2*slow);SetRightWhell(1,(speed-2*slow)/100); //???
					}
					else if(abs(angle-Get_Angle())>44&&abs(angle-Get_Angle())<54)
					{
						SetLeftWhell(1,speed-1*slow);SetRightWhell(1,(speed-1*slow)/100); //???
					}
					else
					{
						SetLeftWhell(1,speed);SetRightWhell(1,speed/2);
					}			
			}
	}
}
/*
*********************************************************************************************************
*	�� �� ��: Infrared_R_Turn8_2
*	����˵��: ������ǰ����
*	��    ��: speed�����ٶ� angle�����Ƕ� engine������ͷ
*	�� �� ֵ:��
*********************************************************************************************************
*/
void Infrared_R_Turn8_2(u8 speed,int angle,int engine,int slow)
{
	while(1)
	{
			if(engine==0)
			{
					if((abs(angle-Get_Angle())>0&&abs(angle-Get_Angle())<5))
					{				
						Stop();
						break;
					}
					else if(abs(angle-Get_Angle())>4&&abs(angle-Get_Angle())<14)
					{
						SetLeftWhell(1,speed-5*slow);SetRightWhell(1,(speed-5*slow)/5); //???
					}
					else if(abs(angle-Get_Angle())>14&&abs(angle-Get_Angle())<24)
					{
						SetLeftWhell(1,speed-4*slow);SetRightWhell(1,(speed-4*slow)/20); //???
					}
					else if(abs(angle-Get_Angle())>24&&abs(angle-Get_Angle())<34)
					{
						SetLeftWhell(1,speed-3*slow);SetRightWhell(1,(speed-3*slow)/50); //???
					}
					else if(abs(angle-Get_Angle())>34&&abs(angle-Get_Angle())<44)
					{
						SetLeftWhell(1,speed-2*slow);SetRightWhell(1,(speed-2*slow)/50); //???
					}
					else if(abs(angle-Get_Angle())>44&&abs(angle-Get_Angle())<54)
					{
						SetLeftWhell(1,speed-1*slow);SetRightWhell(1,(speed-1*slow)/100); //???
					}
					else
					{
						SetLeftWhell(1,speed);SetRightWhell(1,2*speed/3);
					}			
			}
	}
}
/*
*********************************************************************************************************
*	�� �� ��: Infrared_L_Turn9
*	����˵��: �������2����
*	��    ��: speed�����ٶ� angle�����Ƕ� engine������ͷ
*	�� �� ֵ:��
*********************************************************************************************************
*/
void Infrared_L_Turn9(u8 speed,int angle,int engine,int slow)
{
	while(1)
	{
			if(engine==1)
			{
					if((abs(angle-Get_Angle())>0&&abs(angle-Get_Angle())<5))
					{				
						Stop();
						break;
					}
					else if(abs(angle-Get_Angle())>4&&abs(angle-Get_Angle())<14)
					{
						SetLeftWhell(1,(speed-5*slow)/10);SetRightWhell(1,speed-5*slow); //???
					}
					else if(abs(angle-Get_Angle())>14&&abs(angle-Get_Angle())<24)
					{
						SetLeftWhell(1,(speed-4*slow)/50);SetRightWhell(1,speed-4*slow); //???
					}
					else if(abs(angle-Get_Angle())>24&&abs(angle-Get_Angle())<34)
					{
						SetLeftWhell(1,(speed-3*slow)/100);SetRightWhell(1,speed-3*slow); //???
					}
					else if(abs(angle-Get_Angle())>34&&abs(angle-Get_Angle())<44)
					{
						SetLeftWhell(1,(speed-2*slow)/100);SetRightWhell(1,speed-2*slow); //???
					}
					else if(abs(angle-Get_Angle())>44&&abs(angle-Get_Angle())<54)
					{
						SetLeftWhell(1,(speed-1*slow)/100);SetRightWhell(1,speed-1*slow); //???
					}
					else
					{
						SetLeftWhell(1,speed/5);SetRightWhell(1,speed);
					}			
			}
	}
}
/*
*********************************************************************************************************
*	�� �� ��: Infrared_L_Turn9_2
*	����˵��: �������2����
*	��    ��: speed�����ٶ� angle�����Ƕ� engine������ͷ
*	�� �� ֵ:��
*********************************************************************************************************
*/
void Infrared_L_Turn9_2(u8 speed,int angle,int engine,int slow)
{
	while(1)
	{
			if(engine==1)
			{
					if((abs(angle-Get_Angle())>0&&abs(angle-Get_Angle())<5))
					{				
						Stop();
						break;
					}
					else if(abs(angle-Get_Angle())>4&&abs(angle-Get_Angle())<14)
					{
						SetLeftWhell(1,(speed-5*slow)/10);SetRightWhell(1,speed-5*slow); //???
					}
					else if(abs(angle-Get_Angle())>14&&abs(angle-Get_Angle())<24)
					{
						SetLeftWhell(1,(speed-4*slow)/50);SetRightWhell(1,speed-4*slow); //???
					}
					else if(abs(angle-Get_Angle())>24&&abs(angle-Get_Angle())<34)
					{
						SetLeftWhell(1,(speed-3*slow)/100);SetRightWhell(1,speed-3*slow); //???
					}
					else if(abs(angle-Get_Angle())>34&&abs(angle-Get_Angle())<44)
					{
						SetLeftWhell(1,(speed-2*slow)/100);SetRightWhell(1,speed-2*slow); //???
					}
					else if(abs(angle-Get_Angle())>44&&abs(angle-Get_Angle())<54)
					{
						SetLeftWhell(1,(speed-1*slow)/100);SetRightWhell(1,speed-1*slow); //???
					}
					else
					{
						SetLeftWhell(0,speed/10);SetRightWhell(1,speed);
					}			
			}
	}
}
/*
*********************************************************************************************************
*	�� �� ��: Infrared_L_Turn1
*	����˵��: ������󻡶�ת�����
*	��    ��: speed�����ٶ�angle�����Ƕ�engine������ͷ
*	�� �� ֵ: ��
*********************************************************************************************************
*/
void Infrared_L_Turn1(u8 speed,int angle,int engine,int slow)
{
	while(1)
	{
	if(engine==0)
	{
			if((abs(angle-Get_Angle())>0&&abs(angle-Get_Angle())<5))
			{				
				CarAdvance(0);
				break;
			}
			else if(abs(angle-Get_Angle())>4&&abs(angle-Get_Angle())<14)
			{
				SetLeftWhell(1,(speed-5*slow)/100);SetRightWhell(1,speed-5*slow); //???
			}
			else if(abs(angle-Get_Angle())>14&&abs(angle-Get_Angle())<24)
			{
				SetLeftWhell(1,(speed-4*slow)/100);SetRightWhell(1,speed-4*slow); //???
			}
			else if(abs(angle-Get_Angle())>24&&abs(angle-Get_Angle())<34)
			{
				SetLeftWhell(1,(speed-3*slow)/100);SetRightWhell(1,speed-3*slow); //???
			}
			else if(abs(angle-Get_Angle())>34&&abs(angle-Get_Angle())<44)
			{
				SetLeftWhell(1,(speed-2*slow)/100);SetRightWhell(1,speed-2*slow); //???
			}
			else if(abs(angle-Get_Angle())>44&&abs(angle-Get_Angle())<54)
			{
				SetLeftWhell(1,(speed-1*slow)/100);SetRightWhell(1,speed-1*slow); //???
			}
			else
			{
				SetLeftWhell(1,speed/2);SetRightWhell(1,speed);
			}			
}
	else if(engine==1)
	{
		while(1)
		{
			if((angle-(float)3 < Get_Angle()) && (Get_Angle() < angle+(float)3))
			{				
				break;
			}
			else
			{
				SetLeftWhell(0,speed/2);SetRightWhell(1,speed); //???
			}
		}
	}
	}
}

/*
*********************************************************************************************************
*	�� �� ��: Infrared_L_Turn4
*	����˵��: ������ԭ��ת�����
*	��    ��: speed�����ٶ�angle�����Ƕ�
*	�� �� ֵ: ��
*********************************************************************************************************
*/
void Infrared_L_Turn4(int angle)
{
			while(1)
			{
				if((angle-(float)6 < Get_Angle()) && (Get_Angle() < angle+(float)6))
				{	
					Stop();
					break;
				}
				else if((angle-(float)60 < Get_Angle()) && (Get_Angle() < angle+(float)60))
				{
					SetLeftWhell(0,40);SetRightWhell(0,40); //��ԭ��ת��
				}
				else
				{
					SetLeftWhell(0,40);SetRightWhell(0,40); //��ԭ��ת��
				}
			}
}
/*
*********************************************************************************************************
*	�� �� ��: Infrared_L_Turn4_2
*	����˵��: ������ԭ��ת�����
*	��    ��: speed�����ٶ�angle�����Ƕ�
*	�� �� ֵ: ��
*********************************************************************************************************
*/
void Infrared_L_Turn4_2(int angle)
{
			while(1)
			{
				if((angle-(float)6 < Get_Angle()) && (Get_Angle() < angle+(float)6))
				{	
					Stop();
					break;
				}
				else if((angle-(float)60 < Get_Angle()) && (Get_Angle() < angle+(float)60))
				{
					SetLeftWhell(0,25);SetRightWhell(0,25); //��ԭ��ת��
				}
				else
				{
					SetLeftWhell(0,25);SetRightWhell(0,25); //��ԭ��ת��
				}
			}
}
/*
*********************************************************************************************************
*	�� �� ��: Infrared_R_Turn4
*	����˵��: ������ԭ��ת�����
*	��    ��: speed�����ٶ�angle�����Ƕ�
*	�� �� ֵ: ��
*********************************************************************************************************
*/
void Infrared_R_Turn4(int angle)
{
			while(1)
			{
				if((angle-(float)6 < Get_Angle()) && (Get_Angle() < angle+(float)6))
				{	
					Stop();
					break;
				}
				else if((angle-(float)60 < Get_Angle()) && (Get_Angle() < angle+(float)60))
				{
					SetLeftWhell(1,40);SetRightWhell(1,40); //��ԭ��ת��
				}
				else
				{
					SetLeftWhell(1,40);SetRightWhell(1,40); //��ԭ��ת��
				}
			}
}
/*
*********************************************************************************************************
*	�� �� ��: Infrared_R_Turn4_2
*	����˵��: ������ԭ��ת�����
*	��    ��: speed�����ٶ�angle�����Ƕ�
*	�� �� ֵ: ��
*********************************************************************************************************
*/
void Infrared_R_Turn4_2(int angle)
{
			while(1)
			{
				if((angle-(float)6 < Get_Angle()) && (Get_Angle() < angle+(float)6))
				{	
					Stop();
					break;
				}
				else if((angle-(float)60 < Get_Angle()) && (Get_Angle() < angle+(float)60))
				{
					SetLeftWhell(1,25);SetRightWhell(1,25); //��ԭ��ת��
				}
				else
				{
					SetLeftWhell(1,25);SetRightWhell(1,25); //��ԭ��ת��
				}
			}
}
/*
*********************************************************************************************************
*	�� �� ��: Infrared_R_Turn4_3
*	����˵��: ������ԭ��ת�����
*	��    ��: speed�����ٶ�angle�����Ƕ�
*	�� �� ֵ: ��
*********************************************************************************************************
*/
void Infrared_R_Turn4_3(int angle)
{
			while(1)
			{
				if((angle-(float)6 < Get_Angle()) && (Get_Angle() < angle+(float)6))
				{	
					Stop();
					break;
				}
				else if((angle-(float)60 < Get_Angle()) && (Get_Angle() < angle+(float)60))
				{
					SetLeftWhell(1,40);SetRightWhell(1,30); //��ԭ��ת��
				}
				else
				{
					SetLeftWhell(1,40);SetRightWhell(1,30); //��ԭ��ת��
				}
			}
}
/*
*********************************************************************************************************
*	�� �� ��: Infrared_L_Turn2
*	����˵��: ����ԭ����ת�����
*	��    ��: speed�����ٶ�angle�����Ƕ�engine������ͷ
*	�� �� ֵ: ��
*********************************************************************************************************
*/

void Infrared_L_Turn2(u8 speed,int angle,int engine,int slow)
{
	while(1)
	{
	if(engine==0)
	{
			if((abs(angle-Get_Angle())>0&&abs(angle-Get_Angle())<5))
			{				
				CarAdvance(0);
				break;
			}
			else if(abs(angle-Get_Angle())>4&&abs(angle-Get_Angle())<14)
			{
				SetLeftWhell(0,speed-5*slow);SetRightWhell(0,speed-5*slow); //???
			}
			else if(abs(angle-Get_Angle())>14&&abs(angle-Get_Angle())<24)
			{
				SetLeftWhell(0,speed-4*slow);SetRightWhell(0,speed-4*slow); //???
			}
			else if(abs(angle-Get_Angle())>24&&abs(angle-Get_Angle())<34)
			{
				SetLeftWhell(0,speed-3*slow);SetRightWhell(0,speed-3*slow); //???
			}
			else if(abs(angle-Get_Angle())>34&&abs(angle-Get_Angle())<44)
			{
				SetLeftWhell(0,speed-2*slow);SetRightWhell(0,speed-2*slow); //???
			}
			else if(abs(angle-Get_Angle())>44&&abs(angle-Get_Angle())<54)
			{
				SetLeftWhell(0,speed-1*slow);SetRightWhell(0,speed-1*slow); //???
			}
			else
			{
				SetLeftWhell(0,speed);SetRightWhell(0,speed);
			}			
		}
		}		
}

/*
*********************************************************************************************************
*	�� �� ��: Infrared_L_Turn3
*	����˵��: �����󻡶�ת�����
*	��    ��: speed�����ٶ�angle�����Ƕ�engine������ͷ
*	�� �� ֵ: ��
*********************************************************************************************************
*/

void Infrared_L_Turn3(u8 speed,int angle,int engine,int slow)
{
	while(1)
	{
	if(engine==0)
	{
			if((abs(angle-Get_Angle())>0&&abs(angle-Get_Angle())<9))
			{				
				CarAdvance(0);
				break;
			}
			else if(abs(angle-Get_Angle())>8&&abs(angle-Get_Angle())<14)
			{
				SetLeftWhell(1,(speed-5*slow)/100);SetRightWhell(0,speed-5*slow); //???
			}
			else if(abs(angle-Get_Angle())>14&&abs(angle-Get_Angle())<24)
			{
				SetLeftWhell(1,(speed-4*slow)/100);SetRightWhell(0,speed-4*slow); //???
			}
			else if(abs(angle-Get_Angle())>24&&abs(angle-Get_Angle())<34)
			{
				SetLeftWhell(1,(speed-3*slow)/100);SetRightWhell(0,speed-3*slow); //???
			}
			else if(abs(angle-Get_Angle())>34&&abs(angle-Get_Angle())<44)
			{
				SetLeftWhell(1,(speed-2*slow)/100);SetRightWhell(0,speed-2*slow); //???
			}
			else if(abs(angle-Get_Angle())>44&&abs(angle-Get_Angle())<54)
			{
				SetLeftWhell(1,(speed-1*slow)/100);SetRightWhell(0,speed-1*slow); //???
			}
			else
			{
				SetLeftWhell(1,speed/5);SetRightWhell(0,speed);
			}			
		}
	else if(engine==1)
	{

			if((abs(angle-Get_Angle())>0&&abs(angle-Get_Angle())<9))
			{				
				CarAdvance(0);
				break;
			}
			else if(abs(angle-Get_Angle())>8&&abs(angle-Get_Angle())<14)
			{
				SetLeftWhell(0,(speed-5*slow)/100);SetRightWhell(1,speed-5*slow); //???
			}
			else if(abs(angle-Get_Angle())>14&&abs(angle-Get_Angle())<24)
			{
				SetLeftWhell(0,(speed-4*slow)/100);SetRightWhell(1,speed-4*slow); //???
			}
			else if(abs(angle-Get_Angle())>24&&abs(angle-Get_Angle())<34)
			{
				SetLeftWhell(0,(speed-3*slow)/100);SetRightWhell(1,speed-3*slow); //???
			}
			else if(abs(angle-Get_Angle())>34&&abs(angle-Get_Angle())<44)
			{
				SetLeftWhell(0,(speed-2*slow)/100);SetRightWhell(1,speed-2*slow); //???
			}
			else if(abs(angle-Get_Angle())>44&&abs(angle-Get_Angle())<54)
			{
				SetLeftWhell(0,(speed-1*slow)/100);SetRightWhell(1,speed-1*slow); //???
			}
			else
			{
				SetLeftWhell(0,speed/8);SetRightWhell(1,speed);//�˴��ٶ�ԽС������ԽС
			}			

	 }
   }			
}
/*
*********************************************************************************************************
*	�� �� ��: Infrared_R_Turn
*	����˵��: ������ǰ����ת�����
*	��    ��: speed�����ٶ�angle�����Ƕ�engine������ͷ
*	�� �� ֵ: ��
*********************************************************************************************************
*/
void Infrared_R_Turn(u8 speed,int angle,int engine,int slow)
{
	while(1)
	{
		if(engine==0)
		{
				if((abs(angle-Get_Angle())>0&&abs(angle-Get_Angle())<4))
				{				
					CarAdvance(0);
					break;
				}
				else if(abs(angle-Get_Angle())>4&&abs(angle-Get_Angle())<14)
				{
					SetLeftWhell(1,speed-6*slow);SetRightWhell(1,(speed-1*slow)/100); //???
				}
				else if(abs(angle-Get_Angle())>14&&abs(angle-Get_Angle())<24)
				{
					SetLeftWhell(1,speed-4*slow);SetRightWhell(1,(speed-1*slow)/100); //???
				}
				else if(abs(angle-Get_Angle())>24&&abs(angle-Get_Angle())<34)
				{
					SetLeftWhell(1,speed-3*slow);SetRightWhell(1,(speed-1*slow)/100); //???
				}
				else if(abs(angle-Get_Angle())>34&&abs(angle-Get_Angle())<44)
				{
					SetLeftWhell(1,speed-2*slow);SetRightWhell(1,(speed-1*slow)/100); //???
				}
				else if(abs(angle-Get_Angle())>44&&abs(angle-Get_Angle())<54)
				{
					SetLeftWhell(1,speed-1*slow);SetRightWhell(1,(speed-1*slow)/100); //???
				}
				else
				{
					SetLeftWhell(1,speed);SetRightWhell(1,speed/2);
				}			
		}
		else if(engine==1)
		{
			if((abs(angle-Get_Angle())>0&&abs(angle-Get_Angle())<5))
			{				
				CarAdvance(0);
				break;
			}
			else if(abs(angle-Get_Angle())>4&&abs(angle-Get_Angle())<14)
			{
				SetLeftWhell(0,speed-6*slow);SetRightWhell(0,(speed-1*slow)/100); //???
			}
			else if(abs(angle-Get_Angle())>14&&abs(angle-Get_Angle())<24)
			{
				SetLeftWhell(0,speed-4*slow);SetRightWhell(0,(speed-1*slow)/100); //???
			}
			else if(abs(angle-Get_Angle())>24&&abs(angle-Get_Angle())<34)
			{
				SetLeftWhell(0,speed-3*slow);SetRightWhell(0,(speed-1*slow)/100); //???
			}
			else if(abs(angle-Get_Angle())>34&&abs(angle-Get_Angle())<44)
			{
				SetLeftWhell(0,speed-2*slow);SetRightWhell(0,(speed-1*slow)/100); //???
			}
			else if(abs(angle-Get_Angle())>44&&abs(angle-Get_Angle())<54)
			{
				SetLeftWhell(0,speed-1*slow);SetRightWhell(0,(speed-1*slow)/100); //???
			}
			else
			{
				SetLeftWhell(0,speed);SetRightWhell(0,speed/2);
			}			
		}
	}
}
/*
*********************************************************************************************************
*	�� �� ��: Infrared_Rz_Turn
*	����˵��: ������ǰ����ת�����
*	��    ��: speed�����ٶ�angle�����Ƕ�engine������ͷ
*	�� �� ֵ: ��
*********************************************************************************************************
*/
void Infrared_Rz_Turn(u8 speed,int angle,int engine,int slow)
{
	while(1)
	{
		if(engine==0)
		{
				if((abs(angle-Get_Angle())>0&&abs(angle-Get_Angle())<4))
				{				
					CarAdvance(0);
					break;
				}
				else if(abs(angle-Get_Angle())>4&&abs(angle-Get_Angle())<14)
				{
					SetLeftWhell(1,speed-6*slow);SetRightWhell(1,(speed-1*slow)/100); //???
				}
				else if(abs(angle-Get_Angle())>14&&abs(angle-Get_Angle())<24)
				{
					SetLeftWhell(1,speed-4*slow);SetRightWhell(1,(speed-1*slow)/100); //???
				}
				else if(abs(angle-Get_Angle())>24&&abs(angle-Get_Angle())<34)
				{
					SetLeftWhell(1,speed-2*slow);SetRightWhell(1,(speed-1*slow)/100); //???
				}
				else if(abs(angle-Get_Angle())>34&&abs(angle-Get_Angle())<44)
				{
					SetLeftWhell(1,speed-1*slow);SetRightWhell(1,(speed-1*slow)/100); //???
				}
				else if(abs(angle-Get_Angle())>44&&abs(angle-Get_Angle())<54)
				{
					SetLeftWhell(1,speed-1*slow);SetRightWhell(1,(speed-1*slow)/100); //???
				}
				else
				{
					SetLeftWhell(1,speed);SetRightWhell(1,speed);
				}			
	}
	}
}


/*
*********************************************************************************************************
*	�� �� ��: Infrared_R_Turn2
*	����˵��: ������ԭ��ת�����
*	��    ��: speed�����ٶ�angle�����Ƕ�engine������ͷ
*	�� �� ֵ: ��
*********************************************************************************************************
*/

void Infrared_R_Turn2(u8 speed,int angle,int engine,int slow)
{
	while(1)
	{
	if(engine==0)
	{
			if((abs(angle-Get_Angle())>0&&abs(angle-Get_Angle())<5))
			{				
				CarAdvance(0);
				break;
			}
			else if(abs(angle-Get_Angle())>5&&abs(angle-Get_Angle())<14)
			{
				SetLeftWhell(1,speed-5*slow);SetRightWhell(1,speed-5*slow); //???
			}
			else if(abs(angle-Get_Angle())>14&&abs(angle-Get_Angle())<24)
			{
				SetLeftWhell(1,speed-4*slow);SetRightWhell(1,speed-4*slow); //???
			}
			else if(abs(angle-Get_Angle())>24&&abs(angle-Get_Angle())<34)
			{
				SetLeftWhell(1,speed-3*slow);SetRightWhell(1,speed-3*slow); //???
			}
			else if(abs(angle-Get_Angle())>34&&abs(angle-Get_Angle())<44)
			{
				SetLeftWhell(1,speed-2*slow);SetRightWhell(1,speed-2*slow); //???
			}
			else if(abs(angle-Get_Angle())>44&&abs(angle-Get_Angle())<54)
			{
				SetLeftWhell(1,speed-1*slow);SetRightWhell(1,speed-1*slow); //???
			}
			else
			{
				SetLeftWhell(1,speed);SetRightWhell(1,speed/2);
			}			
		}
		}		
}


/*
*********************************************************************************************************
*	�� �� ��: Infrared_R_Turn3
*	����˵��: �����һ���ת�����
*	��    ��: speed�����ٶ�angle�����Ƕ�engine������ͷ
*	�� �� ֵ: ��
*********************************************************************************************************
*/

void Infrared_R_Turn3(u8 speed,int angle,int engine,int slow)
{
	while(1)
	{
	if(engine==0)
	{
			if((abs(angle-Get_Angle())>0&&abs(angle-Get_Angle())<9))
			{				
				CarAdvance(0);
				break;
			}
			else if(abs(angle-Get_Angle())>8&&abs(angle-Get_Angle())<14)
			{
				SetLeftWhell(1,speed-5*slow);SetRightWhell(0,(speed-1*slow)/100); //???
			}
			else if(abs(angle-Get_Angle())>14&&abs(angle-Get_Angle())<24)
			{
				SetLeftWhell(1,speed-4*slow);SetRightWhell(0,(speed-1*slow)/100); //???
			}
			else if(abs(angle-Get_Angle())>24&&abs(angle-Get_Angle())<34)
			{
				SetLeftWhell(1,speed-3*slow);SetRightWhell(0,(speed-1*slow)/100); //???
			}
			else if(abs(angle-Get_Angle())>34&&abs(angle-Get_Angle())<44)
			{
				SetLeftWhell(1,speed-2*slow);SetRightWhell(0,(speed-1*slow)/100); //???
			}
			else if(abs(angle-Get_Angle())>44&&abs(angle-Get_Angle())<54)
			{
				SetLeftWhell(1,speed-1*slow);SetRightWhell(0,(speed-1*slow)/100); //???
			}
			else
			{
				SetLeftWhell(1,speed);SetRightWhell(0,speed/3);
			}			
	}
	else if(engine==1)
	{
			if((abs(angle-Get_Angle())>0&&abs(angle-Get_Angle())<9))
			{				
				CarAdvance(0);
				break;
			}
			else if(abs(angle-Get_Angle())>8&&abs(angle-Get_Angle())<14)
			{
				SetLeftWhell(0,speed-5*slow);SetRightWhell(1,(speed-1*slow)/100); //???
			}
			else if(abs(angle-Get_Angle())>14&&abs(angle-Get_Angle())<24)
			{
				SetLeftWhell(0,speed-4*slow);SetRightWhell(1,(speed-1*slow)/100); //???
			}
			else if(abs(angle-Get_Angle())>24&&abs(angle-Get_Angle())<34)
			{
				SetLeftWhell(0,speed-3*slow);SetRightWhell(1,(speed-1*slow)/100); //???
			}
			else if(abs(angle-Get_Angle())>34&&abs(angle-Get_Angle())<44)
			{
				SetLeftWhell(0,speed-2*slow);SetRightWhell(1,(speed-1*slow)/100); //???
			}
			else if(abs(angle-Get_Angle())>44&&abs(angle-Get_Angle())<54)
			{
				SetLeftWhell(0,speed-1*slow);SetRightWhell(1,(speed-1*slow)/100); //???
			}
			else
			{
				SetLeftWhell(0,speed);SetRightWhell(1,speed/4);//�˴��ٶ�ԽС������ԽС
			}			

	}
}
	}
/*
*********************************************************************************************************
*	�� �� ��: gostraight1
*	����˵��: ����ֱ�߳���
*	��    ��: speed�����ٶ�angle(��õ��ĽǶ�)�����Ƕ�engine������ͷ Get_AngleС����ǰ�Ƕ�
*	�� �� ֵ: ��
*********************************************************************************************************
*/

void gostraight1(u8 speed,int angle,int engine,int slow)
{
	while(1)
	{
	if(engine==0)
		{
			if(abs(angle-Get_Angle())>=0&&abs(angle-Get_Angle())<=1)
				{				
				CarAdvance(90);
				break;
				}
				else if((angle-Get_Angle())>-359&&(angle-Get_Angle())<-354)
				{
					SetLeftWhell(1,speed-3*slow);SetRightWhell(0,speed-2*slow); //???
				}
				else if((angle-Get_Angle())>=-354&&(angle-Get_Angle())<-340)
				{
					SetLeftWhell(1,speed-5*slow);SetRightWhell(0,speed-2*slow); //???
				}
				else if((angle-Get_Angle())>1&&(angle-Get_Angle())<5)
				{
					SetLeftWhell(1,speed-3*slow);SetRightWhell(0,speed-2*slow); //???
				}
				else if((angle-Get_Angle())>=5&&(angle-Get_Angle())<20)
				{
					SetLeftWhell(1,speed-5*slow);SetRightWhell(0,speed-2*slow); //???
				}
				else if((angle-Get_Angle())>-5&&(angle-Get_Angle())<-1)
				{
				SetLeftWhell(1,speed-2*slow);SetRightWhell(0,speed-3*slow); //???
				}
			else if((angle-Get_Angle())>-20&&(angle-Get_Angle())<=-5)
				{
				SetLeftWhell(1,speed-2*slow);SetRightWhell(0,speed-5*slow); //???
				}
			}
     else if(engine==1)
		{
			if((abs(angle-Get_Angle())>=0&&abs(angle-Get_Angle())<2))
				{				
				CarRetreat(90);
				break;
				}
			else if((angle-Get_Angle())>=-358&&(angle-Get_Angle())<-355)
				{
				SetLeftWhell(0,speed-2*slow);SetRightWhell(1,(speed-3*slow)); //???
				}
			else if((angle-Get_Angle())>=-355&&(angle-Get_Angle())<-340)
				{
				SetLeftWhell(0,speed-2*slow);SetRightWhell(1,(speed-5*slow)); //???
				}
				else if((angle-Get_Angle())>=2&&(angle-Get_Angle())<5)
				{
				SetLeftWhell(0,speed-2*slow);SetRightWhell(1,(speed-3*slow)); //???
				}
			else if((angle-Get_Angle())>=5&&(angle-Get_Angle())<20)
				{
				SetLeftWhell(0,speed-2*slow);SetRightWhell(1,(speed-5*slow)); //???
				}
			else if((angle-Get_Angle())>-5&&(angle-Get_Angle())<=-2)
				{
				SetLeftWhell(0,speed-3*slow);SetRightWhell(1,speed-2*slow); //???
				}
			else if((angle-Get_Angle())>=-20&&(angle-Get_Angle())<=-5)
				{
				SetLeftWhell(0,speed-5*slow);SetRightWhell(1,speed-2*slow); //???
				}
			
		}
		
	}		
}
/*
*********************************************************************************************************
*	�� �� ��: gostraight2
*	����˵��: ����ֱ�߳���
*	��    ��: speed�����ٶ�angle(��õ��ĽǶ�)�����Ƕ�engine������ͷ Get_AngleС����ǰ�Ƕ�
*	�� �� ֵ: ��
*********************************************************************************************************
*/

void gostraight2(u8 speed,int angle,int engine,int slow)
{
	while(1)
	{
	if(engine==0)
		{
			if(abs(angle-Get_Angle())>=0&&abs(angle-Get_Angle())<=1)
				{				
				CarAdvance(80);
				break;
				}
				else if((angle-Get_Angle())>-359&&(angle-Get_Angle())<-354)
				{
					SetLeftWhell(1,speed-3*slow);SetRightWhell(0,speed-2*slow); //???
				}
				else if((angle-Get_Angle())>=-354&&(angle-Get_Angle())<-340)
				{
					SetLeftWhell(1,speed-5*slow);SetRightWhell(0,speed-2*slow); //???
				}
				else if((angle-Get_Angle())>1&&(angle-Get_Angle())<5)
				{
					SetLeftWhell(1,speed-3*slow);SetRightWhell(0,speed-2*slow); //???
				}
				else if((angle-Get_Angle())>=5&&(angle-Get_Angle())<20)
				{
					SetLeftWhell(1,speed-5*slow);SetRightWhell(0,speed-2*slow); //???
				}
				else if((angle-Get_Angle())>-5&&(angle-Get_Angle())<-1)
				{
				SetLeftWhell(1,speed-2*slow);SetRightWhell(0,speed-3*slow); //???
				}
			else if((angle-Get_Angle())>-20&&(angle-Get_Angle())<=-5)
				{
				SetLeftWhell(1,speed-2*slow);SetRightWhell(0,speed-5*slow); //???
				}
			}
     else if(engine==1)
		{
			if((abs(angle-Get_Angle())>=0&&abs(angle-Get_Angle())<2))
				{				
				CarRetreat(80);
				break;
				}
			else if((angle-Get_Angle())>=-358&&(angle-Get_Angle())<-355)
				{
				SetLeftWhell(0,speed-2*slow);SetRightWhell(1,(speed-3*slow)); //???
				}
			else if((angle-Get_Angle())>=-355&&(angle-Get_Angle())<-340)
				{
				SetLeftWhell(0,speed-2*slow);SetRightWhell(1,(speed-5*slow)); //???
				}
				else if((angle-Get_Angle())>=2&&(angle-Get_Angle())<5)
				{
				SetLeftWhell(0,speed-2*slow);SetRightWhell(1,(speed-3*slow)); //???
				}
			else if((angle-Get_Angle())>=5&&(angle-Get_Angle())<20)
				{
				SetLeftWhell(0,speed-2*slow);SetRightWhell(1,(speed-5*slow)); //???
				}
			else if((angle-Get_Angle())>-5&&(angle-Get_Angle())<=-2)
				{
				SetLeftWhell(0,speed-3*slow);SetRightWhell(1,speed-2*slow); //???
				}
			else if((angle-Get_Angle())>=-20&&(angle-Get_Angle())<=-5)
				{
				SetLeftWhell(0,speed-5*slow);SetRightWhell(1,speed-2*slow); //???
				}
			
		}
		
	}		
}
/*
*********************************************************************************************************
*	�� �� ��: gostraight3
*	����˵��: ����ֱ�߳���
*	��    ��: speed�����ٶ�angle(��õ��ĽǶ�)�����Ƕ�engine������ͷ Get_AngleС����ǰ�Ƕ�
*	�� �� ֵ: ��
*********************************************************************************************************
*/

void gostraight3(u8 speed,int angle,int engine,int slow)
{
	while(1)
	{
	if(engine==0)
		{
			if(abs(angle-Get_Angle())>=0&&abs(angle-Get_Angle())<=1)
				{				
				CarAdvance(60);
				break;
				}
		
				else if((angle-Get_Angle())>-359&&(angle-Get_Angle())<-354)
				{
					SetLeftWhell(1,speed-3*slow);SetRightWhell(0,speed-2*slow); //???
				}
				else if((angle-Get_Angle())>=-354&&(angle-Get_Angle())<-340)
				{
					SetLeftWhell(1,speed-5*slow);SetRightWhell(0,speed-2*slow); //???
				}
				else if((angle-Get_Angle())>=1&&(angle-Get_Angle())<5)
				{
					SetLeftWhell(1,speed-3*slow);SetRightWhell(0,speed-2*slow); //???
				}
				else if((angle-Get_Angle())>=5&&(angle-Get_Angle())<20)
				{
					SetLeftWhell(1,speed-5*slow);SetRightWhell(0,speed-2*slow); //???
				}
				else if((angle-Get_Angle())>-5&&(angle-Get_Angle())<-1)
				{
				SetLeftWhell(1,speed-2*slow);SetRightWhell(0,speed-3*slow); //???
				}
			else if((angle-Get_Angle())>-20&&(angle-Get_Angle())<=-5)
				{
				SetLeftWhell(1,speed-2*slow);SetRightWhell(0,speed-5*slow); //???
				}
			}
     else if(engine==1)
		{
			if((abs(angle-Get_Angle())>=0&&abs(angle-Get_Angle())<2))
				{				
				CarRetreat(60);
				break;
				}
			else if((angle-Get_Angle())>=-358&&(angle-Get_Angle())<-355)
				{
				SetLeftWhell(0,speed-2*slow);SetRightWhell(1,(speed-3*slow)); //???
				}
			else if((angle-Get_Angle())>=-355&&(angle-Get_Angle())<-351)
				{
				SetLeftWhell(0,speed-2*slow);SetRightWhell(1,(speed-5*slow)); //???
				}
				else if((angle-Get_Angle())>=2&&(angle-Get_Angle())<5)
				{
				SetLeftWhell(0,speed-2*slow);SetRightWhell(1,(speed-3*slow)); //???
				}
			else if((angle-Get_Angle())>=5&&(angle-Get_Angle())<9)
				{
				SetLeftWhell(0,speed-2*slow);SetRightWhell(1,(speed-5*slow)); //???
				}
			else if((angle-Get_Angle())>-5&&(angle-Get_Angle())<=-2)
				{
				SetLeftWhell(0,speed-3*slow);SetRightWhell(1,speed-2*slow); //???
				}
			else if((angle-Get_Angle())>=-8&&(angle-Get_Angle())<=-5)
				{
				SetLeftWhell(0,speed-5*slow);SetRightWhell(1,speed-2*slow); //???
				}
			
		}
		
	}		
}
/*
*********************************************************************************************************
*	�� �� ��: gostraight4
*	����˵��: ����ֱ�߳���
*	��    ��: speed�����ٶ�angle(��õ��ĽǶ�)�����Ƕ�engine������ͷ Get_AngleС����ǰ�Ƕ�
*	�� �� ֵ: ��
*********************************************************************************************************
*/

void gostraight4(u8 speed,int angle,int engine,int slow)
{
	while(1)
	{
	if(engine==0)
		{
			if(abs(angle-Get_Angle())>=0&&abs(angle-Get_Angle())<=1)
				{				
				CarAdvance(50);
				break;
				}
		
				else if((angle-Get_Angle())>-359&&(angle-Get_Angle())<-354)
				{
					SetLeftWhell(1,speed-3*slow);SetRightWhell(0,speed-2*slow); //???
				}
				else if((angle-Get_Angle())>=-354&&(angle-Get_Angle())<-340)
				{
					SetLeftWhell(1,speed-5*slow);SetRightWhell(0,speed-2*slow); //???
				}
				else if((angle-Get_Angle())>=1&&(angle-Get_Angle())<5)
				{
					SetLeftWhell(1,speed-3*slow);SetRightWhell(0,speed-2*slow); //???
				}
				else if((angle-Get_Angle())>=5&&(angle-Get_Angle())<20)
				{
					SetLeftWhell(1,speed-5*slow);SetRightWhell(0,speed-2*slow); //???
				}
				else if((angle-Get_Angle())>-5&&(angle-Get_Angle())<-1)
				{
				SetLeftWhell(1,speed-2*slow);SetRightWhell(0,speed-3*slow); //???
				}
			else if((angle-Get_Angle())>-20&&(angle-Get_Angle())<=-5)
				{
				SetLeftWhell(1,speed-2*slow);SetRightWhell(0,speed-5*slow); //???
				}
			}
     else if(engine==1)
		{
			if((abs(angle-Get_Angle())>=0&&abs(angle-Get_Angle())<2))
				{				
				CarRetreat(50);
				break;
				}
			else if((angle-Get_Angle())>=-358&&(angle-Get_Angle())<-355)
				{
				SetLeftWhell(0,speed-2*slow);SetRightWhell(1,(speed-3*slow)); //???
				}
			else if((angle-Get_Angle())>=-355&&(angle-Get_Angle())<-351)
				{
				SetLeftWhell(0,speed-2*slow);SetRightWhell(1,(speed-5*slow)); //???
				}
				else if((angle-Get_Angle())>=2&&(angle-Get_Angle())<5)
				{
				SetLeftWhell(0,speed-2*slow);SetRightWhell(1,(speed-3*slow)); //???
				}
			else if((angle-Get_Angle())>=5&&(angle-Get_Angle())<9)
				{
				SetLeftWhell(0,speed-2*slow);SetRightWhell(1,(speed-5*slow)); //???
				}
			else if((angle-Get_Angle())>-5&&(angle-Get_Angle())<=-2)
				{
				SetLeftWhell(0,speed-3*slow);SetRightWhell(1,speed-2*slow); //???
				}
			else if((angle-Get_Angle())>=-8&&(angle-Get_Angle())<=-5)
				{
				SetLeftWhell(0,speed-5*slow);SetRightWhell(1,speed-2*slow); //???
				}
			
		}
		
	}		
}
/*
*********************************************************************************************************
*	�� �� ��: gostraight5
*	����˵��: ����ֱ�߳���
*	��    ��: speed�����ٶ�angle(��õ��ĽǶ�)�����Ƕ�engine������ͷ Get_AngleС����ǰ�Ƕ�
*	�� �� ֵ: ��
*********************************************************************************************************
*/

void gostraight5(u8 speed,int angle,int engine,int slow)
{
	while(1)
	{
	if(engine==0)
		{
			if(abs(angle-Get_Angle())>=0&&abs(angle-Get_Angle())<=1)
				{				
				CarAdvance(40);
				break;
				}
		
				else if((angle-Get_Angle())>-359&&(angle-Get_Angle())<-354)
				{
					SetLeftWhell(1,speed-3*slow);SetRightWhell(0,speed-2*slow); //???
				}
				else if((angle-Get_Angle())>=-354&&(angle-Get_Angle())<-340)
				{
					SetLeftWhell(1,speed-5*slow);SetRightWhell(0,speed-2*slow); //???
				}
				else if((angle-Get_Angle())>=1&&(angle-Get_Angle())<5)
				{
					SetLeftWhell(1,speed-3*slow);SetRightWhell(0,speed-2*slow); //???
				}
				else if((angle-Get_Angle())>=5&&(angle-Get_Angle())<20)
				{
					SetLeftWhell(1,speed-5*slow);SetRightWhell(0,speed-2*slow); //???
				}
				else if((angle-Get_Angle())>-5&&(angle-Get_Angle())<-1)
				{
				SetLeftWhell(1,speed-2*slow);SetRightWhell(0,speed-3*slow); //???
				}
			else if((angle-Get_Angle())>-20&&(angle-Get_Angle())<=-5)
				{
				SetLeftWhell(1,speed-2*slow);SetRightWhell(0,speed-5*slow); //???
				}
			}
     else if(engine==1)
		{
			if((abs(angle-Get_Angle())>=0&&abs(angle-Get_Angle())<2))
				{				
				CarRetreat(40);
				break;
				}
			else if((angle-Get_Angle())>=-358&&(angle-Get_Angle())<-355)
				{
				SetLeftWhell(0,speed-2*slow);SetRightWhell(1,(speed-3*slow)); //???
				}
			else if((angle-Get_Angle())>=-355&&(angle-Get_Angle())<-351)
				{
				SetLeftWhell(0,speed-2*slow);SetRightWhell(1,(speed-5*slow)); //???
				}
				else if((angle-Get_Angle())>=2&&(angle-Get_Angle())<5)
				{
				SetLeftWhell(0,speed-2*slow);SetRightWhell(1,(speed-4*slow)); //???
				}
			else if((angle-Get_Angle())>=5&&(angle-Get_Angle())<9)
				{
				SetLeftWhell(0,speed-2*slow);SetRightWhell(1,(speed-5*slow)); //???
				}
			else if((angle-Get_Angle())>-5&&(angle-Get_Angle())<=-2)
				{
				SetLeftWhell(0,speed-3*slow);SetRightWhell(1,speed-2*slow); //???
				}
			else if((angle-Get_Angle())>=-8&&(angle-Get_Angle())<=-5)
				{
				SetLeftWhell(0,speed-5*slow);SetRightWhell(1,speed-2*slow); //???
				}
			
		}
		
	}		
}
/*
*********************************************************************************************************
*	�� �� ��: gostraight6
*	����˵��: ����ֱ�߳���
*	��    ��: speed�����ٶ�angle(��õ��ĽǶ�)�����Ƕ�engine������ͷ Get_AngleС����ǰ�Ƕ�
*	�� �� ֵ: ��
*********************************************************************************************************
*/

void gostraight6(u8 speed,int angle,int engine,int slow)
{
	while(1)
	{
	if(engine==0)
		{
			if(abs(angle-Get_Angle())>=0&&abs(angle-Get_Angle())<=1)
				{				
				CarAdvance(30);
				break;
				}
		
				else if((angle-Get_Angle())>-359&&(angle-Get_Angle())<-354)
				{
					SetLeftWhell(1,speed-3*slow);SetRightWhell(0,speed-2*slow); //???
				}
				else if((angle-Get_Angle())>=-354&&(angle-Get_Angle())<-340)
				{
					SetLeftWhell(1,speed-5*slow);SetRightWhell(0,speed-2*slow); //???
				}
				else if((angle-Get_Angle())>=1&&(angle-Get_Angle())<5)
				{
					SetLeftWhell(1,speed-3*slow);SetRightWhell(0,speed-2*slow); //???
				}
				else if((angle-Get_Angle())>=5&&(angle-Get_Angle())<20)
				{
					SetLeftWhell(1,speed-5*slow);SetRightWhell(0,speed-2*slow); //???
				}
				else if((angle-Get_Angle())>-5&&(angle-Get_Angle())<-1)
				{
				SetLeftWhell(1,speed-2*slow);SetRightWhell(0,speed-3*slow); //???
				}
			else if((angle-Get_Angle())>-20&&(angle-Get_Angle())<=-5)
				{
				SetLeftWhell(1,speed-2*slow);SetRightWhell(0,speed-5*slow); //???
				}
			}
     else if(engine==1)
		{
			if((abs(angle-Get_Angle())>=0&&abs(angle-Get_Angle())<2))
				{				
				CarRetreat(30);
				break;
				}
			else if((angle-Get_Angle())>=-358&&(angle-Get_Angle())<-355)
				{
				SetLeftWhell(0,speed-2*slow);SetRightWhell(1,(speed-3*slow)); //???
				}
			else if((angle-Get_Angle())>=-355&&(angle-Get_Angle())<-351)
				{
				SetLeftWhell(0,speed-2*slow);SetRightWhell(1,(speed-5*slow)); //???
				}
				else if((angle-Get_Angle())>=2&&(angle-Get_Angle())<5)
				{
				SetLeftWhell(0,speed-2*slow);SetRightWhell(1,(speed-4*slow)); //???
				}
			else if((angle-Get_Angle())>=5&&(angle-Get_Angle())<9)
				{
				SetLeftWhell(0,speed-2*slow);SetRightWhell(1,(speed-5*slow)); //???
				}
			else if((angle-Get_Angle())>-5&&(angle-Get_Angle())<=-2)
				{
				SetLeftWhell(0,speed-3*slow);SetRightWhell(1,speed-2*slow); //???
				}
			else if((angle-Get_Angle())>=-8&&(angle-Get_Angle())<=-5)
				{
				SetLeftWhell(0,speed-5*slow);SetRightWhell(1,speed-2*slow); //???
				}
			
		}
		
	}		
}
/*
*********************************************************************************************************
*	�� �� ��: hh
*	����˵��: ���洫����ת��
*	��    ��: speed�����ٶ�angle�����Ƕ�engine������ͷ 
*	�� �� ֵ: ��
*********************************************************************************************************
*/
void hh(u8 speed,int engine,int slow)
{
	while(1)
	{
		if(engine==0)
		{
				if(Laser_scan(0)==0x00&&(Get_Angle()==180||Get_Angle()==90))
					{							
						CarAdvance(0);
						break;
					}
				else if(!Gray1&&!I_DIO4&&L02==1&&L06==1)
					{
						Stop();
						break;				//???
					}	
				else if(hy1(0)<0)
					{
						if(L08==1)
						{
							SetLeftWhell(1,speed-1*slow);SetRightWhell(1,(speed-1*slow)/10); //???
						}
						else if(L01==1)
						{
							SetLeftWhell(1,speed-1*slow);SetRightWhell(1,(speed-1*slow)/10); //???
						}
						else if(L07==1)
						{
							SetLeftWhell(1,speed-2*slow);SetRightWhell(1,speed-2*slow); //???
						}
						else if(L02==1)
						{  
							SetLeftWhell(1,speed);SetRightWhell(0,4*speed/5); //???
						}
					}
				else if(hy1(0)>0)
					{
							 if(L06==1&&L03==1&&L05==1)
						{
							SetLeftWhell(0,speed/2);SetRightWhell(0,speed/2);
						}
						else if(L04==1||L05==1)
						{
						  SetLeftWhell(0,speed);SetRightWhell(0,speed);
						}
						else
						{
						SetLeftWhell(1,speed);SetRightWhell(0,speed);
						}
					}
				else if(hy1(0)==0&&Laser_scan(0)!=0x00)
					{
						SetLeftWhell(1,speed-1*slow);SetRightWhell(0,speed-1*slow);  //???
					}
		}
		if(engine==1)
		{
				if(Laser_scan(1)==0x00&&(Get_Angle()==90||Get_Angle()==0))
					{							
						CarAdvance(0);
						break;
					}
				else if(!Gray2&&!I_DIO1&&L15==1&&L14==1)
					{
						Stop();
						break;				//???
					}	
				else if(hy1(1)>0)
					{
						if(L18==1)
						{
							SetLeftWhell(1,(speed-1*slow)/20);SetRightWhell(1,speed); //???
						}
						else if(L17==1)
						{
							SetLeftWhell(0,(speed-1*slow)/10);SetRightWhell(1,speed-1*slow); //???
						}
						else if(L16==1)
						{
							SetLeftWhell(1,(speed-3*slow)/3);SetRightWhell(1,speed-3*slow); //???
						}
						else if(L15==1)
						{  
							SetLeftWhell(0,4*speed/5);SetRightWhell(1,speed); //???
						}
					}
				else if(hy1(1)<0)
					{
							 if(L14==1&&L13==1)
						{
							SetLeftWhell(0,speed);SetRightWhell(0,speed);
						}
						else if(L11==1||L12==1)
						{
						  SetLeftWhell(0,speed);SetRightWhell(0,speed);
						}
						else
						{
						SetLeftWhell(0,speed);SetRightWhell(1,speed);
						}
					}
				else if(hy1(1)==0&&Laser_scan(1)!=0x00)
					{
						SetLeftWhell(0,speed-1*slow);SetRightWhell(1,speed-1*slow);  //???
					}
		}
	}
}
/*
*********************************************************************************************************
*	�� �� ��: hh1
*	����˵��: ���洫����ת��
*	��    ��: speed�����ٶ�angle�����Ƕ�engine������ͷ 
*	�� �� ֵ: ��
*********************************************************************************************************
*/
void hh1(u8 speed,int engine,int slow)
{
	while(1)
	{
		if(engine==0)
		{
				if(Laser_scan(0)==0x00&&(Get_Angle()==180||Get_Angle()==90))
					{							
						CarAdvance(0);
						break;
					}
				else if(!Gray1&&!I_DIO4&&L02==1&&L06==1)
					{
						Stop();
						break;				//???
					}	
				else if(hy1(0)<0)
					{
						if(L08==1)
						{
							SetLeftWhell(1,speed-1*slow);SetRightWhell(1,(speed-1*slow)/50); //???
						}
						else if(L01==1)
						{
							SetLeftWhell(1,speed-1*slow);SetRightWhell(1,(speed-1*slow)/8); //???
						}
						else if(L07==1)
						{
							SetLeftWhell(1,speed-1*slow);SetRightWhell(1,(speed-1*slow)/6); //???
	          }
						else if(L02==1)
						{  
							SetLeftWhell(1,speed);SetRightWhell(0,4*speed/5); //???
						}
					}
				else if(hy1(0)>0)
					{
							 if(L06==1&&L03==1&&L05==1)
						{
							SetLeftWhell(0,speed);SetRightWhell(0,speed);
						}
						else if(L04==1||L05==1)
						{
						  SetLeftWhell(0,speed);SetRightWhell(0,speed);
						}
						else
						{
						SetLeftWhell(1,speed);SetRightWhell(0,speed);
						}
					}
				else if(hy1(0)==0&&Laser_scan(0)!=0x00)
					{
						SetLeftWhell(1,speed-1*slow);SetRightWhell(0,speed-1*slow);  //???
					}
		}
		if(engine==1)
		{
				if(Laser_scan(1)==0x00&&(Get_Angle()==90||Get_Angle()==0))
					{							
						CarAdvance(0);
						break;
					}
				else if(!Gray2&&!I_DIO1&&L15==1&&L14==1)
					{
						Stop();
						break;				//???
					}	
				else if(hy1(1)>0)
					{
						if(L18==1)
						{
							SetLeftWhell(1,(speed-1*slow)/2);SetRightWhell(1,speed-1*slow); //???
						}
						else if(L17==1)
						{
							SetLeftWhell(1,(speed-1*slow)/4);SetRightWhell(1,speed-1*slow); //???
						}
						else if(L16==1)
						{
							SetLeftWhell(1,speed-3*slow);SetRightWhell(1,speed-3*slow); //???
						}
						else if(L15==1)
						{  
							SetLeftWhell(0,4*speed/5);SetRightWhell(1,speed); //???
						}
					}
				else if(hy1(1)<0)
					{
							 if(L14==1&&L13==1)
						{
							SetLeftWhell(0,speed);SetRightWhell(0,speed);
						}
						else if(L12==1)
						{
						  SetLeftWhell(0,speed);SetRightWhell(0,speed);
						}
						else
						{
						SetLeftWhell(0,speed);SetRightWhell(1,speed);
						}
					}
				else if(hy1(1)==0&&Laser_scan(1)!=0x00)
					{
						SetLeftWhell(0,speed-1*slow);SetRightWhell(1,speed-1*slow);  //???
					}
		}
	}
}
/*
*********************************************************************************************************
*	�� �� ��: hh2
*	����˵��: ���洫����ת��
*	��    ��: speed�����ٶ�angle�����Ƕ�engine������ͷ 
*	�� �� ֵ: ��
*********************************************************************************************************
*/
void hh2(u8 speed,int engine,int slow)
{
	while(1)
	{
		if(engine==0)
		{
				if(Laser_scan(0)==0x00&&(Get_Angle()==180||Get_Angle()==90))
					{							
						CarAdvance(0);
						break;
					}
				else if(!Gray1&&!I_DIO4&&L02==1&&L06==1)
					{
						Stop();
						break;				//???
					}	
				else if(hy1(0)<0)
					{
						if(L08==1)
						{
							SetLeftWhell(1,speed-1*slow);SetRightWhell(1,(speed-1*slow)/4); //???
						}
						else if(L01==1)
						{
							SetLeftWhell(1,speed-1*slow);SetRightWhell(1,(speed-1*slow)/4); //???
						}
						else if(L07==1)
						{
							SetLeftWhell(1,speed-2*slow);SetRightWhell(1,speed-2*slow); //???
						}
						else if(L02==1)
						{  
							SetLeftWhell(1,speed);SetRightWhell(0,4*speed/5); //???
						}
					}
				else if(hy1(0)>0)
					{
							 if(L06==1&&L03==1&&L05==1)
						{
							SetLeftWhell(0,speed/2);SetRightWhell(0,speed/2);
						}
						else
						{
						SetLeftWhell(1,speed);SetRightWhell(0,speed);
						}
					}
				else if(hy1(0)==0&&Laser_scan(0)!=0x00)
					{
						SetLeftWhell(1,speed-1*slow);SetRightWhell(0,speed-1*slow);  //???
					}
		}
		if(engine==1)
		{
				if(Laser_scan(1)==0x00&&(Get_Angle()==90||Get_Angle()==0))
					{							
						CarAdvance(0);
						break;
					}
				else if(!Gray2&&!I_DIO1&&L15==1&&L14==1)
					{
						Stop();
						break;				//???
					}	
				else if(hy1(1)>0)
					{
						if(L18==1)
						{
							SetLeftWhell(1,(speed-1*slow)/4);SetRightWhell(1,speed-1*slow); //???
						}
						else if(L17==1)
						{
							SetLeftWhell(1,(speed-1*slow)/4);SetRightWhell(1,speed-1*slow); //???
						}
						else if(L16==1)
						{
							SetLeftWhell(1,speed-3*slow);SetRightWhell(1,speed-3*slow); //???
						}
						else if(L15==1)
						{  
							SetLeftWhell(0,4*speed/5);SetRightWhell(1,speed); //???
						}
					}
				else if(hy1(1)<0)
					{
							 if(L14==1&&L13==1&&L12==1)
						{
							SetLeftWhell(0,speed/2);SetRightWhell(0,speed/2);
						}
						else
						{
						SetLeftWhell(0,speed);SetRightWhell(1,speed);
						}
					}
				else if(hy1(1)==0&&Laser_scan(1)!=0x00)
					{
						SetLeftWhell(0,speed-1*slow);SetRightWhell(1,speed-1*slow);  //???
					}
		}
	}
}
/*
*********************************************************************************************************
*	�� �� ��: tz
*	����˵��: ����
*	��    ��: speed�����ٶ�angle�����Ƕ�engine������ͷ 
*	�� �� ֵ: ��
*********************************************************************************************************
*/
void tz(u8 speed,int slow)
{
	
	   if(Laser_scan(0)==0x00)
			{				
				CarAdvance(0);
			}
			else if(!Gray1&&(!I_DIO4||!I_PWM6))
			{
				Stop();
			}				//???
			else if(hy1(0)<0)
			{
				if(L01==1)
				{
					SetLeftWhell(1,speed-1*slow);SetRightWhell(1,speed-1*slow); //???
				}
				else if(L08==1)
				{
					SetLeftWhell(1,speed-1*slow);SetRightWhell(1,speed-1*slow); //???
				}
				else if(L02==1)
				{
					SetLeftWhell(1,speed-3*slow);SetRightWhell(1,speed-3*slow); //???
				}
				else if(L07==1)
				{  
					SetLeftWhell(1,speed);SetRightWhell(0,6*speed/7); //???
				}
//				SetLeftWhell(1,speed-5*slow);SetRightWhell(1,speed-5*slow); //???
			}
			else if(hy1(0)>0)
			{
					 if(L03==1)
				{
					SetLeftWhell(1,6*speed/7);SetRightWhell(0,speed);
				}
				else if(L06==1)
				{
					SetLeftWhell(0,speed-1*slow);SetRightWhell(0,speed-1*slow);
				}
				else if(L04==1)
				{
					SetLeftWhell(0,speed-1*slow);SetRightWhell(0,speed-1*slow);
				}
				else if(L05==1)
				{
					SetLeftWhell(0,speed-1*slow);SetRightWhell(0,speed-1*slow);
				}
//				SetLeftWhell(0,speed-4*slow);SetRightWhell(0,speed-4*slow); //???
			}
			else if(hy1(0)==0&&Laser_scan(0)!=0x00)
			{
				SetLeftWhell(1,speed-1*slow);SetRightWhell(0,speed-1*slow);  //???
			}
	}
/*
*********************************************************************************************************
*	�� �� ��: sd
*	����˵��: ����
*	��    ��: speed�����ٶ�angle�����Ƕ�engine������ͷ 
*	�� �� ֵ: ��
*********************************************************************************************************
*/
	void sd()
{
	switch(Laser_scan(0))
	{
		case 0x80:
					 Infrared_R_Turn4(101);
						gostraight1(60,101,0,10);
						break;
		case 0x01:
						 Infrared_R_Turn4(124);
							gostraight1(60,124,0,10);
							break;
		case 0x40:
						 Infrared_R_Turn4(147);
							gostraight1(60,147,0,10);
							break;
		case 0x02:
						 Infrared_R_Turn4(169);
							gostraight1(60,169,0,10);
							break;
	}

}
/*
*********************************************************************************************************
*	�� �� ��: hy1
*	����˵��: ���洫����ת��
*	��    ��: speed�����ٶ�angle�����Ƕ�engine������ͷ 
*	�� �� ֵ: ��
*********************************************************************************************************
*/
int hy1(int aspect)
{
int L,R;
L=R=0;
if(aspect==0)
	{
	if(L03==1) L=1;
	if(L07==1) R=1;
	if(L06==1) L=2;
	if(L02==1) R=2;
	if(L04==1) L=3;
	if(L08==1) R=3;
	if(L05==1) L=4;
	if(L01==1) R=4;
	
	}
	else if(aspect==1)
	{
	if(L16==1) L=1;
	if(L13==1) R=1;
	if(L15==1) L=2;
	if(L14==1) R=2;
	if(L18==1) L=3;
	if(L11==1) R=3;
	if(L17==1) L=4;
	if(L12==1) R=4;
	}
	return(L-R);
}
/*
*********************************************************************************************************
*	�� �� ��: go
*	����˵��: ���洫����ת��
*	��    ��: speed�����ٶ�angle�����Ƕ�engine������ͷ 
*	�� �� ֵ: ��
*********************************************************************************************************
*/
void go(u8 speed,int angle,int engine,int slow)
{
	while(1)
 {
		if(engine==0)
	{
			if((abs(angle-Get_Angle())>0&&abs(angle-Get_Angle())<2))
			{				
				CarAdvance(40);
				break;
			}
			else if((angle-Get_Angle())>-358&&(angle-Get_Angle())<-350)
			{
				SetLeftWhell(1,speed-3*slow);SetRightWhell(0,(speed-2*slow)); //???
			}
			else if((angle-Get_Angle())>-350&&(angle-Get_Angle())<-340)
			{
				SetLeftWhell(1,speed-5*slow);SetRightWhell(0,(speed-2*slow)); //???
			}
				else if((angle-Get_Angle())>-10&&(angle-Get_Angle())<-2)
			{
				SetLeftWhell(1,speed-2*slow);SetRightWhell(0,(speed-3*slow)); //???
			}
			else if((angle-Get_Angle())>-20&&(angle-Get_Angle())<-10)
			{
				SetLeftWhell(1,speed-2*slow);SetRightWhell(0,(speed-5*slow)); //???
			}
			else if((angle-Get_Angle())>2&&(angle-Get_Angle())<4)
			{
				SetLeftWhell(1,speed-3*slow);SetRightWhell(0,(speed-2*slow)); //???
			}
			else if((angle-Get_Angle())>4&&(angle-Get_Angle())<10)
			{
				SetLeftWhell(1,speed-5*slow);SetRightWhell(0,(speed-2*slow)); //???
			}
		}
	if(engine==1)
	{
			if((abs(angle-Get_Angle())>0&&abs(angle-Get_Angle())<2))
			{				
				CarRetreat(40);
				break;
			}
			else if((angle-Get_Angle())>-358&&(angle-Get_Angle())<-356)
			{
				SetLeftWhell(0,speed-5*slow);SetRightWhell(1,(speed-2*slow)); //???
			}
				else if((angle-Get_Angle())>-356&&(angle-Get_Angle())<-354)
			{
				SetLeftWhell(0,speed-5*slow);SetRightWhell(1,(speed-2*slow)); //???
			}
			else if((angle-Get_Angle())>-4&&(angle-Get_Angle())<-2)
			{
				SetLeftWhell(0,speed-2*slow);SetRightWhell(1,(speed-5*slow)); //???
			}
			else if((angle-Get_Angle())>-6&&(angle-Get_Angle())<-4)
			{
				SetLeftWhell(0,speed-2*slow);SetRightWhell(1,(speed-5*slow)); //???
			}
      else if((angle-Get_Angle())>2&&(angle-Get_Angle())<4)
			{
				SetLeftWhell(0,speed-5*slow);SetRightWhell(1,(speed-2*slow)); //???
			}
			else if((angle-Get_Angle())>4&&(angle-Get_Angle())<6)
			{
				SetLeftWhell(0,speed-5*slow);SetRightWhell(1,(speed-2*slow)); //???
			}
		}
	}
}

/*
*********************************************************************************************************
*	�� �� ��: scanf_blaze
*	����˵��: ��ⷿ���Ƿ���ڻ�Դ
*	��    ��: speed�����ٶ�engine������ͷ
*	�� �� ֵ: ��
*********************************************************************************************************
*/
int scanf_blaze(float angle,int engine)
{
	   if(engine==0)
		 {
				if(Laser_scan(0)==0x00)
				{
					return 0;
				}
				else
					return 1;
		}
		 if(engine==1)
		{
			if(Laser_scan(1)==0x00)
				{
					return 0;
				}
				else
					return 1;
			
		} 
	}



/*
*********************************************************************************************************
*	�� �� ��: Hunt_door
*	����˵��: Ѱ�ҷ���
*	��    ��: speed�����ٶ�angle��¼���ӽ��ŽǶ�
*	�� �� ֵ: ��
*********************************************************************************************************
*/
void Hunt_door(u8 speed,float angle)
{
	
}
/*
*********************************************************************************************************
*	�� �� ��: start1
*	����˵��: ǰ����һ����
*	��    ��: ��
*	�� �� ֵ: ��
*********************************************************************************************************
*/
void start1()
{		
/*******ǰ����һ������*******/	
	
	while(!I_ETR4)
	{
		if(!I_PWM6)
		gostraight4(50,0,0,6);
		else
		CarAdvance(25);
	}
	Infrared_R_Turn8(50,270,0,4);
	while(I_PWM7)
	{
	gostraight2(80,270,0,8);
	}
	while(!I_PWM7&&I_ETR4)
	{
	gostraight2(80,270,0,8);
	}
	while(!I_PWM7&&!I_ETR4)
	{
		if(I_PWM6)
		{
			CarAdvance(25);
		}
		else
		{
	   gostraight2(80,270,0,8);
		}
	}
	Infrared_R_Turn(50,180,0,3);
	while(!I_DIO1)
	{
	gostraight5(40,180,0,6);
	}
	Stop();
}
/*
*********************************************************************************************************
*	�� �� ��: start2
*	����˵��: ǰ���ڶ�����
*	��    ��: ��
*	�� �� ֵ: ��
*********************************************************************************************************
*/
   void start2()
  {
		
	while(I_DIO1)
	{
		gostraight5(40,180,1,6);
	}
	Infrared_R_Turn5(50,270,1,3);
		
	while(!I_PWM7)
	{
		if(!I_DIO2)
		gostraight2(80,270,1,6);
		else
		CarRetreat(30);
	}
	Infrared_L_Turn(50,180,1,4);
	while(I_PWM7&&I_ETR4)
	{
	gostraight3(60,180,1,6);
	}
	while(!I_PWM7)
	{
		if(!I_DIO2)
		gostraight3(60,180,1,6);
		else
		gostraight5(40,180,1,6);
	}
	Infrared_L_Turn(45,80,1,3);
	while(!I_DIO4)
	{
	gostraight5(40,80,1,6);
	}
	Stop();
	delay_ms(200);
}
	

/*
*********************************************************************************************************
*	�� �� ��: start3
*	����˵��: ǰ����������
*	��    ��: ��
*	�� �� ֵ: ��
*********************************************************************************************************
*/
 void start3()
{
		while(I_DIO4)
			{
			gostraight5(40,90,0,6);
			}
			Infrared_L_Turn7(50,180,0,6);
		while(!I_ETR4)
			{
			  gostraight4(50,180,0,6);
			}
			Infrared_R_Turn8(50,90,0,6);
		while(!I_DIO1)
			{
			gostraight5(40,90,0,6);
			}
      Stop();
}


/*
*********************************************************************************************************
*	�� �� ��: start4
*	����˵��: ǰ�����ķ���
*	��    ��: ��
*	�� �� ֵ: ��
*********************************************************************************************************
*/
void start4()
{
	  while(!I_PWM7)
		{
   gostraight5(40,90,1,6);
		}
		Infrared_L_Turn9_2(50,358,1,3);
  while(!I_ETR4)
			{
			  CarRetreat(40);
			}
			Infrared_L_Turn6(50,270,1,3);
	while(I_PWM7&&I_ETR4)
	{
	 gostraight4(50,270,1,6);
	}
	Infrared_R_Turn5_4(50,0,1,4);
	while(!I_DIO4)
	{
	gostraight5(40,0,1,6);
	}
  Stop();
	delay_ms(300);
}
/*
*********************************************************************************************************
*	�� �� ��: start5
*	����˵��: ǰ�����������
*	��    ��: ��
*	�� �� ֵ: ��
*********************************************************************************************************
*/
void s5()
{
	
	   while(I_DIO4)
				{
					gostraight6(30,0,0,4);
				}
				Infrared_R_Turn4_2(270);
//		 Infrared_R_Turn8_2(50,265,0,4);
		 while(!I_PWM7)
				{
				gostraight4(50,270,0,4);
				}
			while(I_ETR4||I_PWM7)
				{
					gostraight4(50,260,0,4);
				}
			while(!I_ETR4)
				{
					gostraight4(40,265,0,6);
				}
				Infrared_R_Turn8(50,180,0,4);
			while(!I_DIO1)
				{
				gostraight5(40,180,0,6);
				}
      Stop();
				delay_ms(300);
}

/*
*********************************************************************************************************
*	�� �� ��: Back_home1
*	����˵��: ��һ����ؼ�
*	��    ��: ��
*	�� �� ֵ: ��
*********************************************************************************************************
*/
void Back_home1()
{
//	int t=1;
	int b;
	if( Laser_scan(0)!=0x00)
	{
   hh(40,0,3);
//		while(t)
//		{
//		fan(0,0);
//			delay_ms(2000);
//			if(Laser_scan(0)==0x00)
//				t=0,fan(1,0);
			for(b=1;b<=5;b++)
			{
				if(Laser_scan(0)!=0x00)
				{
					fan(0,0);
					delay_ms(1500);
				}
				else
				{
					fan(1,0);
					delay_ms(500);
				}
			}

		
		
	}
	if( Laser_scan(0)==0x00)
	{   
		  while(Get_Angle()!=180)
		{ 
			
		  if(Get_Angle()<91)
				{
					Infrared_L_Turn4_2(90);
					 while(!I_ETR4)
					 {
					 gostraight5(40,90,1,6);
					 }
					 Infrared_R_Turn5(50,180,1,3); 
				}
			else if(Get_Angle()>180)
				{   
					Infrared_L_Turn6_2(50,180,1,4);		
				}
			else if(Get_Angle()<180&&Get_Angle()>=90)
				{
					 Infrared_R_Turn4(125);
						while(I_DIO1)
					{
						CarRetreat(15);
					}
					Infrared_R_Turn5(40,180,1,3);	
				}
				break;
		}
		while(I_DIO1)
		{
		gostraight5(40,180,1,6);
		}
		Infrared_R_Turn5(40,270,1,3);
		while(!I_PWM7)
		{
		gostraight5(40,270,1,6);
		}
		Infrared_R_Turn5_2(40,0,1,4);	
		while(I_DIO1)
		{
		gostraight5(40,0,1,6);
		}
		while(!I_DIO1||I_PWM7||!Gray2)
		{
		Stop();
    }	
    while(1)
		{
		Stop();
		}			
	
	}
	}

/*
*********************************************************************************************************
*	�� �� ��: Back_home2
*	����˵��: �ڶ�����ؼ�
*	��    ��: ��
*	�� �� ֵ: ��
*********************************************************************************************************
*/
void Back_home2()
{
	int b=1;
	if(Laser_scan(1)!=0x00)
	{
   hh(40,1,5);
		for(b=1;b<=5;b++)
			{
				if(Laser_scan(1)!=0x00)
				{
					fan(0,1);
					delay_ms(1500);
				}
				else
				{
					fan(1,0);
					delay_ms(500);
				}
//		while(tt)
//		{
//		fan(0,1);
//			delay_ms(2000);
//			if(Laser_scan(1)==0x00)
//				tt=0,fan(1,1);
   	}	
	}
	if(Laser_scan(1)==0x00)
	{
		  while(Get_Angle()!=90)
		{ 
			
		  if(Get_Angle()<359&&Get_Angle()>270)
				{
					 while(I_DIO4)
					 {
						 CarAdvance(15);
//					 gostraight5(40,0,0,6);
					 }
					 Infrared_L_Turn7_2(40,90,0,3);
				}
			else if(Get_Angle()>90&&Get_Angle()<180)
				{
					Infrared_R_Turn8(45,90,0,4);			
				}
			else if(Get_Angle()<90)
				{
					Infrared_R_Turn4_2(0); 
						while(I_DIO4)
					{
					gostraight5(40,0,0,6);
					}
					Infrared_L_Turn7(40,90,0,3);
//					Infrared_L_Turn4_2(90);	
				}
				break;
		}
		while(I_DIO4)
		{
		gostraight5(40,90,0,6);
		}
		Infrared_L_Turn7(40,180,0,3);
		while(!I_ETR4)
		{
		gostraight5(40,180,0,6);
		}
		while(!I_PWM7)
		{
		gostraight5(40,180,0,6);
		}
		while(I_PWM7)
		{
		gostraight5(40,180,0,6);
		}
	  while(I_DIO4)
		{
		gostraight5(40,180,0,6);
		}
		while(!I_DIO4||I_ETR4||!Gray1)
		{
		Stop();
    }	
    while(1)
		{
		 Stop();
		}			
	}
		
		
}


/*
*********************************************************************************************************
*	�� �� ��: Back_home3
*	����˵��: ��������ؼ�
*	��    ��: ��
*	�� �� ֵ: ��
*********************************************************************************************************
*/
void Back_home3()
{
	int b=1;
	if( Laser_scan(0)!=0x00)
	{
   hh1(40,0,5);
		for(b=1;b<=5;b++)
			{
				if(Laser_scan(0)!=0x00)
				{
					fan(0,0);
					delay_ms(1500);
				}
				else
				{
					fan(1,0);
					delay_ms(500);
				}
//		while(ttt)
//		{
//		fan(0,0);
//			delay_ms(2000);
//			if(Laser_scan(0)==0x00)
//				ttt=0,fan(1,0);
		}
	}
	if( Laser_scan(0)==0x00)
	{
		while(Get_Angle()!=90)
		{ 
			
		  if(Get_Angle()>270&&Get_Angle()<=359)
				{
//					 Infrared_L_Turn4_2(359); 
					 while(I_DIO1)
					 {
						 CarRetreat(15);
					 }
					 Infrared_R_Turn5_4(45,90,1,4); 
				}
			else if(Get_Angle()>90&&Get_Angle()<180)
				{
					
				Infrared_R_Turn4_3(90);			
				}
			else if(Get_Angle()<90)
				{
					Infrared_R_Turn4_2(20);	
						while(I_DIO1)
					{
						CarRetreat(20);
//					gostraight5(40,0,1,6);
					}
					Infrared_R_Turn5(40,90,1,3);
				}
				break;
		}
		while(I_DIO1)
		{
		gostraight5(40,90,1,6);
		}
		Infrared_L_Turn6(50,0,1,4);
		while(!I_PWM7)
		{
		gostraight5(40,0,1,6);
		}
		while(I_PWM7)
		{
		gostraight5(40,0,1,6);
		}
		while(I_DIO1)
		{
		gostraight5(40,0,1,6);
		}
		while(!I_DIO1||!Gray2||I_ETR4)
		{
		Stop();
		}
		while(1)
		{
		Stop();
		}
	}
}


/*
*********************************************************************************************************
*	�� �� ��: Back_home4
*	����˵��: ���ķ���ؼ�
*	��    ��: ��
*	�� �� ֵ: ��
*********************************************************************************************************
*/
void Back_home4()
{
	int b=1;
	if(Laser_scan(1)!=0x00)
	{
   hh1(40,1,5);
		for(b=1;b<=5;b++)
			{
				if(Laser_scan(1)!=0x00)
				{
					fan(0,1);
					delay_ms(1500);
				}
				else
				{
					fan(1,0);
					delay_ms(500);
				}
//		while(tttt)
//		{
//		fan(0,1);
//			delay_ms(2000);
//			if(Laser_scan(1)==0x00)
//				tttt=0,fan(1,1);
		}	
	}
	if(Laser_scan(1)==0x00)
	{
		    while(Get_Angle()!=0)
		{ 
			
		  if(Get_Angle()<271&&Get_Angle()>=180)
				{
					Infrared_L_Turn4_2(270);
					 while(!I_PWM7)
					 {
					 CarAdvance(15);
					 }
					 Infrared_L_Turn7(30,0,0,4);
				}
			 else if(Get_Angle()>0&&Get_Angle()<90)
				{	
				Infrared_R_Turn4_2(0);			
				}
			else if(Get_Angle()<359&&Get_Angle()>=270)
				{
					Infrared_R_Turn4_2(270);
					while(I_DIO4)	
						{
						 CarAdvance(15);
						}					
					Infrared_L_Turn7_3(40,0,0,4);
				}
				break;
		}
			while(I_DIO4)
			{
				gostraight5(40,0,0,6);
			}
			Infrared_R_Turn8(50,270,0,4);
			while(!I_PWM7)
			{
			gostraight6(30,270,0,4);
			}
			Infrared_R_Turn8(50,180,0,4);
			while(I_DIO4&&Gray1)
			{
			gostraight5(40,180,0,6);
			}
			Stop();	
			while(1)
			{
			Stop();
			}
	  }
}



/*
*********************************************************************************************************
*	�� �� ��: Accident
*	����˵��: δ���ֻ�Դ
*	��    ��: ��
*	�� �� ֵ: ��
*********************************************************************************************************
*/
void Accident()
{
	delay_ms(2000);
		while(1)
		{
			int firsearch=0;
			int a;
			for(a=1;a<=4;a++)
			{ 
				switch(a)
				{
					case 1:
						s5();
						firsearch=scanf_blaze(180,0);
						break;
					case 2:
						start2();
						firsearch=scanf_blaze(90,1);
						break;
					case 3:
						start3();
						firsearch=scanf_blaze(90,0);
						break;
					case 4:
						start4();
						firsearch=scanf_blaze(180,1);
						break;
				} 
				if(firsearch == 1)
					
					break;
				
			} 
			switch(a)
			{
				case 1:
					Back_home1();
					break;
				case 2:
					Back_home2();
					break;
				case 3:
					Back_home3();
					break;
				case 4:
					Back_home4();
					break;
			} 
		Stop();
}
}
